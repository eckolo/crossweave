"""Derive report tables from saved raw counts; no simulation changes."""
import csv,json,statistics
from collections import Counter
from pathlib import Path
from sim import ratio

ROOT=Path(__file__).parent
D={}
TR=[]
for directory in ['results']:
    D.update(json.loads((ROOT/directory/'summary.json').read_text()))
    with (ROOT/directory/'trials.csv').open() as f:
        for r in csv.DictReader(f):
            TR.append({k: v if k in ['condition','role'] else float(v) for k,v in r.items()})

def counts(v,role,lo=0,hi=20):
    x=Counter()
    for e in v['encounters'][lo:hi]: x.update(e[role])
    return x

def dist(c,prefix='attr_'):
    return [ratio(c.get(prefix+str(j),0),c.get('draws',0)) for j in range(4)]

def tv(a,b): return sum(abs(x-y) for x,y in zip(a,b))/2

def quantile(values,p):
    values=sorted(values)
    i=(len(values)-1)*p
    lo=int(i);hi=min(lo+1,len(values)-1)
    return values[lo]*(hi-i)+values[hi]*(i-lo) if hi!=lo else values[lo]

def hist_summary(v,part,positive=False):
    h=Counter()
    censored=Counter()
    for k,values in v['histograms'].items():
        if part in k:
            target=censored if k.endswith('censored') else h
            for n,freq in values.items():
                n=int(n)
                if not positive or n>0 or k.endswith('censored'): target[n]+=freq
    expanded=[n for n,f in h.items() for _ in range(f)]
    return {'n':sum(h.values()),'median':quantile(expanded,.5) if expanded else 0,
            'p90':quantile(expanded,.9) if expanded else 0,'max':max(h,default=0),
            'censored_n':sum(censored.values()),'censored_max':max(censored,default=0)}

metrics=[]
for name,v in D.items():
    for role in 'PVE':
        c=v['roles'][role];late=counts(v,role,15,20)
        trials=[t for t in TR if t['condition']==name and t['role']==role]
        m={'condition':name,'role':role,
            'draw_F_pct':100*ratio(c.get('draw_F',0),c['draws']),
            'topup_event_pct':100*ratio(c.get('topup_events',0),c.get('rebuilds',0)),
            'generated_share_pct':100*ratio(c.get('generated_B',0)+c.get('generated_F',0),c.get('rebuilt_received',0)),
            'generated_B_per_run':c.get('generated_B',0)/1000,
            'generated_F_per_run':c.get('generated_F',0)/1000,
            'matches_pct':100*ratio(c.get('matches',0),c['actions']),
            'late_dominant_pct':100*ratio(late['draw_dominant'],late['draws']),
            'late_own_origin_pct':100*ratio(late['draw_own_origin'],late['draws']),
            'foregone_match_pct':100*ratio(c.get('foregone_match',0),c['actions']),
            'F_in_hand_pct':100*ratio(c.get('filler_in_hand_actions',0),c['actions']),
            'all_F_hand_pct':100*ratio(c.get('all_filler_actions',0),c['actions']),
            'P95_run_F_pct':100*quantile([t['filler_draw_rate'] for t in trials],.95),
            'max_run_F_pct':100*max(t['filler_draw_rate'] for t in trials),
            'runs_with_F_pct':100*sum(t.get('draw_F',0)>0 for t in trials)/len(trials),
            'blocked_total_events':c.get('blocked_total_events',0),
            'filler_threshold_events':c.get('filler_threshold_events',0),
            'doomed_threshold_events':c.get('doomed_threshold_events',0),
            'transient_threshold_events':c.get('transient_threshold_events',0),
            'mean_private_stock':ratio(c['private_stock_sum'],c['private_stock_samples'])}
        metrics.append(m)

out=ROOT/'analysis'
out.mkdir(exist_ok=True)
(out/'metrics.json').write_text(json.dumps(metrics,indent=2))
with (out/'metrics.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(metrics[0]));w.writeheader();w.writerows(metrics)

print('ALL CONDITION PLAYER METRICS')
for m in metrics:
    if m['role']=='P': print(m['condition'], {k:round(m[k],3) for k in ['draw_F_pct','topup_event_pct','generated_B_per_run','generated_F_per_run','matches_pct','P95_run_F_pct','max_run_F_pct','late_dominant_pct']})

detail={}
for name in ['baseline','env_cap_6','env_cap_24','hoard_minimum_2','hoard_floor_40',
             'hoard_filler_first','hoard_expiry_first','combined_stress','combined_stress_filler',
             'persistent_enemy','gap_0','deadline_1','deadline_4','affinity_12','environment_replacement']:
    v=D[name];p=counts(v,'P',15,20);e=counts(v,'V',15,20)
    detail[name]={'late_distributions':{r:dist(counts(v,r,15,20)) for r in 'PVE'},
        'pooled_PV_TV':tv(dist(p),dist(e)),
        'histograms':{key:hist_summary(v,key,positive=key=='departed_survival') for key in ['V_deck','P_deck','P_hand','field','departed_survival']},
        'N_round_mean':v['global_sums']['N_sum']/v['global_sums']['rounds'],
        'N_final_mean':v['global_sums']['N_final']/1000,
        'F_round_mean':v['global_sums']['F_sum']/v['global_sums']['rounds'],
        'F_final_mean':v['global_sums']['F_final']/1000,
        'F_max_mean':v['global_sums']['F_max']/1000,
        'below_floor_round_pct':100*v['global_sums']['below_floor_rounds']/v['global_sums']['rounds']}
    paired={}
    for t in TR:
        if t['condition']==name and t['role'] in ('P','V'):
            paired.setdefault(t['seed'],{})[t['role']]=[
                ratio(t['late_attr_'+str(j)],t['late_draws']) for j in range(4)]
    run_tv=[tv(x['P'],x['V']) for x in paired.values()]
    detail[name]['per_run_PV_TV_mean']=statistics.mean(run_tv)
    detail[name]['per_run_PV_TV_P95']=quantile(run_tv,.95)
(out/'detail.json').write_text(json.dumps(detail,indent=2))
print('DETAIL BASELINE',json.dumps(detail['baseline']))
print('MASKING COUNTS',[(m['condition'],m['role'],m['filler_threshold_events'],m['doomed_threshold_events'],m['transient_threshold_events']) for m in metrics if m['transient_threshold_events']])

for name in ['baseline','env_cap_24','hoard_minimum_2','combined_stress']:
    trials=[t for t in TR if t['condition']==name and t['role']=='P']
    worst=max(trials,key=lambda t:t['filler_draw_rate'])
    print('REPLAY CANDIDATE',name,'seed',int(worst['seed']),worst['filler_draw_rate'])

if __name__=='__main__': pass
