import unittest
from dataclasses import replace
from sim import Config, Sim

class CirculationRules(unittest.TestCase):
    def test_filler_is_counted_for_generation(self):
        s=Sim(replace(Config(),floor=25,env_cap=24),0)
        p,v=s.actors['P'],s.actors['V']
        for c in p.deck:
            s.move(c,'deck',v);v.deck.append(c)
        p.deck=[]
        f=s.new_card(v,'F',3)
        s.move(f,'field');s.field[3]=f
        self.assertEqual(s.n,25)
        s.rebuild(p)
        self.assertEqual([c.kind for c in p.deck],['F']*3)
        self.assertEqual(s.stats['P']['generated_B'],0)
        self.assertEqual(s.n,28)
        s.validate()

    def test_departure_respects_origin_and_zone(self):
        s=Sim(Config(),0)
        s.add_actor('E1','E',2)
        p,e=s.actors['P'],s.actors['E']
        # Move three player cards to the enemy so its later return can be checked.
        foreign=p.deck[:3];p.deck=p.deck[3:]
        for c in foreign: s.move(c,'deck',e);e.deck.append(c)
        owned=e.deck[:4];e.deck=e.deck[4:]
        for c,zone in zip(owned,['hand','deck','field','pool']):
            if zone=='hand':
                s.move(c,zone,p);c.remaining=2;p.hand.append(c)
            elif zone=='deck': s.move(c,zone,p);p.deck.append(c)
            elif zone=='field': s.move(c,zone);s.field[c.attr]=c
            else: s.move(c,zone);s.pool.append(c)
        s.retire('E')
        self.assertEqual(s.n,27)
        self.assertEqual(s.doomed_live,3)
        self.assertTrue(all(c in s.pool and not c.dead for c in foreign))
        self.assertTrue(owned[3].dead)
        self.assertTrue(all(not c.dead for c in owned[:3]))
        c=p.hand.pop()
        s.recover(c,'test_recovery')
        self.assertTrue(c.dead)
        self.assertEqual(s.n,26)
        s.validate()

    def test_doomed_card_is_counted_for_generation(self):
        s=Sim(replace(Config(),floor=25,env_cap=24),0)
        p,v=s.actors['P'],s.actors['V']
        for c in p.deck: s.move(c,'deck',v);v.deck.append(c)
        p.deck=[]
        d=s.new_card(v,'I',3)
        d.origin='departed';d.origin_role='E'
        s.retired['departed']=0;s.doomed_live=1
        s.move(d,'field');s.field[3]=d
        s.rebuild(p)
        self.assertEqual(s.stats['P']['generated_B'],0)
        self.assertEqual(s.stats['P']['generated_F'],3)
        s.validate()

    def test_hand_deadline_only_on_own_action(self):
        s=Sim(Config(),0)
        s.action('P')
        saved=list(s.actors['P'].hand)
        self.assertEqual([c.remaining for c in saved],[1,1])
        s.action('V')
        self.assertEqual([c.remaining for c in saved],[1,1])
        s.action('P')
        self.assertTrue(all(c not in s.actors['P'].hand for c in saved))
        s.validate()

    def test_total_deficit_caps_basic_generation(self):
        s=Sim(replace(Config(),floor=25,env_cap=24),0)
        p,v=s.actors['P'],s.actors['V']
        for c in p.deck: s.move(c,'deck',v);v.deck.append(c)
        p.deck=[]
        s.rebuild(p)
        self.assertEqual(s.stats['P']['generated_B'],1)
        self.assertEqual(s.stats['P']['generated_F'],2)
        s.validate()

    def test_full_run_conservation(self):
        for cfg in [Config(),replace(Config(),env_cap=24),replace(Config(),deadline=1),
                    replace(Config(),env_period=5),replace(Config(),enemy_persists=True,gap=0)]:
            Sim(cfg,7,check=True).run()

if __name__=='__main__': unittest.main()
