"""Additional circulation measurements for design 0.6 environment transitions.

Uses the approved amounts, 5x8-round phase timing, continuous-enemy control,
and a further 8-round observation window after boss retirement. No HP rules.
"""
import argparse,csv,json,statistics,time
from collections import Counter
from dataclasses import asdict,replace
from pathlib import Path
from sim import Config,Sim,ratio

ROOT=Path(__file__).parent

def configurations():
    return [replace(Config(),name=f'boss_{mode}_cap{cap}',env_cap=cap,gap=0,
                    enemy_persists=True,env_period=5 if mode=='swap' else 0)
            for cap in (6,12,24) for mode in ('hold','swap')]

class FollowSim(Sim):
    def __init__(self,*args,**kwargs):
        self.cohorts=[]
        self.cohort_draws=Counter()
        self.cohort_matches=Counter()
        self.tracking=True
        super().__init__(*args,**kwargs)

    def retire(self,role):
        if role!='V': return super().retire(role)
        a=self.actors[role]
        before=self.state()
        uid=a.uid
        super().retire(role)
        left=[c for c in self.cards.values() if not c.dead and c.origin==uid]
        cohort={'origin':uid,'round':self.round,'encounter':self.enc+1,
                'before':before,'after_retirement':self.state(),
                'initial_remaining':len(left),
                'P_private':sum(c.owner==self.actors['P'].uid for c in left),
                'E_private':sum(c.owner==self.actors['E'].uid for c in left),
                'field':sum(c.zone=='field' for c in left),
                'last_seen_round':self.round,'cleared_lag':0 if not left else None,
                'trajectory':[]}
        self.cohorts.append(cohort)

    def move(self,c,zone,a=None):
        super().move(c,zone,a)
        if self.tracking and zone=='hand' and self.cohorts:
            age=self.round-self.cohorts[-1]['round']
            if 1<=age<=40:
                key=f'{age}:{a.role}:'
                self.cohort_draws[key+'draws']+=1
                self.cohort_draws[key+'dominant']+=c.attr==a.dom
                if c.origin_role=='V':
                    self.cohort_draws[key+('old_V' if c.origin in self.retired else 'current_V')]+=1

    def recover(self,c,reason):
        if self.tracking and self.cohorts and self.active_uid:
            age=self.round-self.cohorts[-1]['round']
            if 1<=age<=40 and c.origin_role=='V' and c.origin in self.retired:
                role=self.all_actors[self.active_uid].role
                self.cohort_matches[f'{age}:{role}:{reason}']+=1
        super().recover(c,reason)

    def play_round(self,combat):
        super().play_round(combat)
        if self.tracking:
            for cohort in self.cohorts:
                lag=self.round-cohort['round']
                if not 1<=lag<=40:continue
                left=[c for c in self.cards.values() if not c.dead and c.origin==cohort['origin']]
                if left:cohort['last_seen_round']=self.round
                elif cohort['cleared_lag'] is None:cohort['cleared_lag']=lag
                cohort['trajectory'].append({'lag':lag,'remaining':len(left),
                    'P_private':sum(c.owner==self.actors['P'].uid for c in left),
                    'E_private':sum(c.owner==self.actors.get('E',self.actors['P']).uid for c in left) if 'E' in self.actors else 0,
                    'field':sum(c.zone=='field' for c in left)})

    def measured_run(self):
        super().run()
        main={r:Counter(v) for r,v in self.stats.items()}
        boss_exit=self.state()
        self.tracking=False
        follow=[]
        for lag in range(1,9):
            self.play_round(False)
            follow.append({'lag':lag,**self.state()})
        self.validate()
        post={r:self.stats[r]-main[r] for r in ('P','V')}
        return main,post,boss_exit,follow

def q(x,p):
    if not x:return None
    s=sorted(x);i=(len(s)-1)*p;lo=int(i);hi=min(lo+1,len(s)-1)
    return s[lo]+(s[hi]-s[lo])*(i-lo)

def run(seeds,out):
    out.mkdir(exist_ok=True)
    summaries={};rows=[];cohort_rows=[]
    for cfg in configurations():
        start=time.time()
        totals={r:Counter() for r in ('P','V','E')}
        post_totals={r:Counter() for r in ('P','V')}
        draws=Counter();matches=Counter();cohorts=[];trajectory={};post_traj={}
        exits=Counter()
        for seed in range(seeds):
            s=FollowSim(cfg,seed,check=seed==0)
            main,post,ex,follow=s.measured_run()
            for r in ('P','V','E'):
                totals[r].update(main[r])
                rows.append({'condition':cfg.name,'seed':seed,'role':r,'window':'boss_alive',**dict(main[r])})
            for r in ('P','V'):
                post_totals[r].update(post[r])
                rows.append({'condition':cfg.name,'seed':seed,'role':r,'window':'after_boss_8',**dict(post[r])})
            draws.update(s.cohort_draws);matches.update(s.cohort_matches)
            for c in s.cohorts:
                cohorts.append(c)
                cohort_rows.append({'condition':cfg.name,'seed':seed,
                    **{k:c[k] for k in ('origin','round','initial_remaining','P_private','E_private','field','cleared_lag')}})
                for t in c['trajectory']:
                    z=trajectory.setdefault(t['lag'],Counter())
                    z['samples']+=1;z['any_remaining']+=t['remaining']>0
                    for k in ('remaining','P_private','E_private','field'):z[k]+=t[k]
            for t in follow:
                z=post_traj.setdefault(t['lag'],Counter())
                for k in ('N','filler','doomed','pool','field'):z[k]+=t[k]
            for k in ('N','filler','doomed','pool'):exits[k]+=ex[k]
        cleared=[c['cleared_lag'] for c in cohorts if c['cleared_lag'] is not None]
        n=len(cohorts)
        summaries[cfg.name]={'config':asdict(cfg),'seeds':seeds,'main_roles':totals,
            'post_roles':post_totals,'post_boss_round_sums':post_traj,'boss_exit_sums':exits,
            'cohort_draws':draws,'cohort_matches':matches,'old_environment_trajectory':trajectory,
            'swap_summary':{'count':n,
                'remaining_mean':ratio(sum(c['initial_remaining'] for c in cohorts),n),
                'P_private_mean':ratio(sum(c['P_private'] for c in cohorts),n),
                'E_private_mean':ratio(sum(c['E_private'] for c in cohorts),n),
                'field_mean':ratio(sum(c['field'] for c in cohorts),n),
                'P_has_old_rate':ratio(sum(c['P_private']>0 for c in cohorts),n),
                'E_has_old_rate':ratio(sum(c['E_private']>0 for c in cohorts),n),
                'clearance_median':q(cleared,.5),'clearance_P90':q(cleared,.9),
                'clearance_max':max(cleared,default=0),'uncleared_after_40':n-len(cleared)}}
        print(cfg.name,'P F%',100*ratio(totals['P']['draw_F'],totals['P']['draws']),
              'post P F%',100*ratio(post_totals['P']['draw_F'],post_totals['P']['draws']),
              'swap',summaries[cfg.name]['swap_summary'],f'{time.time()-start:.1f}s',flush=True)
        (out/'summary.json').write_text(json.dumps(summaries,indent=2))
    keys=['condition','seed','role','window']+sorted(set().union(*(r.keys() for r in rows))-{'condition','seed','role','window'})
    with (out/'trials.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys,restval=0);w.writeheader();w.writerows(rows)
    with (out/'transitions.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(cohort_rows[0]));w.writeheader();w.writerows(cohort_rows)

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--seeds',type=int,default=1000)
    p.add_argument('--out',type=Path,default=ROOT/'followup_results')
    p.add_argument('--trace');p.add_argument('--seed',type=int,default=0)
    a=p.parse_args()
    if a.trace:
        cfg=next(c for c in configurations() if c.name==a.trace)
        s=FollowSim(cfg,a.seed,trace=True,check=True)
        main_stats,post,ex,post_traj=s.measured_run()
        a.out.mkdir(exist_ok=True)
        path=a.out/f'{a.trace}_seed{a.seed}.json'
        path.write_text(json.dumps({'config':asdict(cfg),'seed':a.seed,'main_stats':main_stats,
            'post_stats':post,'boss_exit':ex,'post_trajectory':post_traj,'cohorts':s.cohorts,'events':s.events},indent=2))
        print(path)
    else:run(a.seeds,a.out)

if __name__=='__main__':main()
