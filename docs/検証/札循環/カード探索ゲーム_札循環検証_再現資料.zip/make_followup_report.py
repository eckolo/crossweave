"""Append the design-0.6 followup to the original report; safe to rerun."""
import csv
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).parent
MARKER = '\n## 11. 追加検証：ボスを残した環境交代（設計版0.6）\n'
NOTE = '追加検証：設計版0.6（更新日時2026-09-06T19:52:51Z）で導入された、継続ボス戦中の環境交代を6条件×1,000シードで確認。第11節を参照。元の36条件は版0.4を参照した検証として保持する。  \n'
REVIEW_NOTE = '最新照合：2026-09-07（UTC）に設計版0.7を確認。回復資源・環境自己進行・未採用の行動コストについて構造上の照合を第12節へ追加。追加の数値実験ではない。  \n'


def pct(a, b):
    return f'{100*a/b:.3f}%' if b else '—'


def table(headers, rows):
    return '\n'.join(['| ' + ' | '.join(headers) + ' |',
                      '|' + '|'.join(['---'] * len(headers)) + '|'] +
                     ['| ' + ' | '.join(map(str, r)) + ' |' for r in rows])


def main():
    data = json.loads((ROOT/'followup_results/summary.json').read_text())
    original = json.loads((ROOT/'results/summary.json').read_text())
    assert data['boss_hold_cap12']['main_roles'] == original['persistent_enemy']['roles']
    trace = json.loads((ROOT/'traces/boss_swap_cap12_seed0.json').read_text())
    with (ROOT/'followup_results/trials.csv').open() as f:
        trials = list(csv.DictReader(f))
    for window, key in [('boss_alive','main_stats'), ('after_boss_8','post_stats')]:
        for role, stats in trace[key].items():
            raw = next(r for r in trials if r['condition']=='boss_swap_cap12'
                       and r['seed']=='0' and r['role']==role and r['window']==window)
            assert all(int(raw[k]) == v for k, v in stats.items())
    assert len(trials) == 6 * 1000 * 5
    with (ROOT/'followup_results/transitions.csv').open() as f:
        transitions = list(csv.DictReader(f))
    assert len(transitions) == 9000

    rows = []
    for name, d in data.items():
        roles = d['main_roles']
        row = [f"{d['config']['env_cap']}／{'交代あり' if 'swap' in name else '交代なし'}"]
        row += [pct(roles[r].get('draw_F',0), roles[r]['draws']) for r in ('P','V','E')]
        row += [pct(roles[r].get('topup_events',0), roles[r]['rebuilds']) for r in ('P','E')]
        rows.append(row)
    main_table = table(['環境受取上限／条件','PのFドロー率','VのFドロー率','EのFドロー率','Pの生成発生率','Eの生成発生率'], rows)

    rows = []
    for cap in (6,12,24):
        s = data[f'boss_swap_cap{cap}']['swap_summary']
        rows.append([cap, f"{s['remaining_mean']:.3f}", f"{s['P_private_mean']:.3f}",
                     f"{s['E_private_mean']:.3f}", f"{s['field_mean']:.3f}",
                     pct(s['E_has_old_rate'],1),s['clearance_median'],s['clearance_P90'],s['clearance_max']])
    cohort_table = table(['環境上限','残存総枚数','P私有','E私有','場','Eが1枚以上保持','消滅中央値（巡）','P90（巡）','最大（巡）'], rows)

    d = data['boss_swap_cap12']
    rows = []
    for lag in (1,3,5,7,8,12):
        z = d['old_environment_trajectory'][str(lag)]
        rows.append([lag,f"{z['remaining']/z['samples']:.3f}",pct(z['any_remaining'],z['samples'])])
    lag_table = table(['交代後の経過巡数','旧環境札の残存枚数平均','1枚以上残る交代の割合'], rows)

    draws = d['cohort_draws']
    rows = []
    for lo, hi in ((1,4),(5,8),(9,12),(13,20),(21,40)):
        for r in ('P','V','E'):
            def total(k):
                return sum(draws.get(f'{lag}:{r}:{k}',0) for lag in range(lo,hi+1))
            n = total('draws')
            rows.append([f'{lo}〜{hi}',r,n,pct(total('old_V'),n),pct(total('current_V'),n),pct(total('dominant'),n)])
    mix_table = table(['交代後の巡','主体','ドロー数','旧環境由来','現環境由来','本人の主属性'], rows)

    rows = []
    for name, d in data.items():
        p = d['post_roles']['P']
        end = d['post_boss_round_sums']['8']
        rows.append([f"{d['config']['env_cap']}／{'交代あり' if 'swap' in name else '交代なし'}",
                     pct(p.get('draw_F',0),p['draws']),f"{p.get('generated_B',0)/d['seeds']:.3f}",
                     f"{p.get('generated_F',0)/d['seeds']:.3f}",f"{end['N']/d['seeds']:.3f}",
                     f"{end['doomed']/d['seeds']:.3f}"])
    post_table = table(['環境上限／条件','PのFドロー率','PのB生成／列','PのF生成／列','8巡後N平均','8巡後消滅予定札平均'],rows)

    appendix = MARKER + f'''
### 11.1 追加した理由と未確定条件の扱い

前回の`environment_replacement`では、敵が退場した後に環境を交代させていた。版0.6は、イベント結果により環境を踏破して穏やかな環境へ交代し、同じボスとプレイヤーの状態を持ち越す展開を許容する。そこで「ボスが旧環境札を持ち続ける」「新環境の初期傾向が再び混ざる」「ボス退場後の継続で補填が必要になる」を追加確認した。

参照は`source_metadata_followup.json`に記録した版0.6。新環境の能力・札効果・初期枚数・初回行動・HP下限、ボス後の追加踏破の実際の長さは未確定。今回は既承認の札枚数・期限・上限の範囲を再使用し、効果やHPを推測で追加していない。「穏やかさ」の効果量を決めた実験ではなく、交代時の札移動と残存の検証である。

- 同じ敵E1を160巡維持。交代あり条件では40・80・120巡終了後にVを退場させ、初期札12枚・同じB傾向の新Vを配置する。P/Eの手札・山札を持ち越す。交代なし条件と比較。
- Vの再構築受取上限6／12／24を組み合わせた6条件。各シード0〜999。手札3/1/3、最低枚数3/1/3、期限2、総量下限32、行動順VPEなどは基準と同じ。
- **NにはFと消滅予定札を含める。** 消滅時にだけNを減らす。基本札は不足を伴う再構築時だけ生成する。
- 160巡終了時にボスを退場させ、P/Vだけでさらに8巡を観測。この8巡は検証用の観測窓であり、正式な踏破所要時間ではない。
- 交代あり各条件は3交代×1,000列＝3,000交代。交代ごとの残存数と、その後40巡までの旧環境由来札を追跡。同じ列の3交代は独立した3,000試行とは扱わない。
- 比率は分子・分母を合算。期間は交代から旧環境札が全領域で0になる最初の巡末まで。各主体の行動回数換算や札の効果持続時間とは区別する。

### 11.2 補填は交代の必然ではない

ボス生存中160巡の集計：

{main_table}

全6条件で生存中のB生成は0、Vの生成発生率も0。上限6/12ではP/V/EのF生成・Fドローとも0。上限24ではPとEにFが発生するが、交代あり／なしで平均ドロー率は近く、今回の条件では環境交代が補填を大幅に増やす結果にはならなかった。微差から改善・悪化の有意性を主張しない。

上限12・交代なしの全主体の生カウンターは、前回の`persistent_enemy`の160巡集計と完全一致した。追加計測によって対照条件の動作が変わっていないことを確認した。

### 11.3 ボスが旧環境札を抱えたまま交代する

旧V退場直後（新Vの初期札投入前）の、退場したVを出現元とする札だけを計数。私有は手札＋山札。回収山の旧V札は退場処理で消滅している。

{cohort_table}

上限12では交代直後に平均5.414枚が残り、約86.0%の交代でボスが少なくとも1枚保持した。中央値5.5巡は離散値5巡と6巡の中間値。全交代で40巡の観測内に消滅し、観測打切りは0件。

{lag_table}

この数字から、旧環境由来の札が交代直後から無効になるとは扱えない。一方、残った札が危険か、有利な借用資源か、無視できるかは札効果次第であり、残存枚数を被害量へ換算しない。

**出現元と保持者を区別する必要がある。** 第7節までの「大きな環境山札は退場した敵由来札を長く残す」は、環境が保持者として残る場合の結果。本節では環境自身が退場するため、本人が保持していた本人由来札もまとめて消滅する。上限24の旧環境札残存平均が約4.0枚と少ないことと矛盾しない。敵退場時の残存期間を、そのまま環境退場時へ流用しない。

### 11.4 交代で初期傾向は戻るが、その後再び混ざる

上限12・交代あり。各セルの分母は該当期間の全ドロー。Pの主属性A、VはB、EはC。「現環境由来」はその時点で生存中のVが出現元の札であり、主属性Bと同義ではない。

{mix_table}

新Vは最初の12行動を自身の初期札で行うため、この間の現環境由来ドローは100%、主属性は約50%。13〜20巡には自身由来34.4%・主属性28.2%まで低下する。初期札を入れ替えるだけで、長時間の環境固有構成まで維持できるわけではない。

P/Eが交代直後1〜4巡に引く札の約24%は旧環境由来。穏やかさを「新環境本人の能力」へ置く場合と、「新環境の持参札の効果」だけへ置く場合とでは、プレイヤーが変化を感じる時期も持続も異なり得る。この区別を戦闘・環境設計との統合で決める必要がある。

### 11.5 再現例：交代7巡後にもボスが旧環境札を設置

`python3 followup.py --trace boss_swap_cap12 --seed 0 --out traces`

| 時点 | 具体的な経過 |
|---|---|
| 40巡終了・交代前 | N36、回収山6、場0。Pは手札1＋山札10、V0は手札0＋山札8、E1は手札2＋山札9 |
| V0退場直後 | N33、回収山11、旧V0由来9枚が消滅予定として残る。内訳P4枚・E1に5枚。これら9枚もNに含む |
| 新V5配置 | 初期札12枚を追加してN45。P/Eの私有札はそのまま |
| 41巡 | E1が旧V0札ID21・B属性を設置。巡末も旧V0札8枚が残る |
| 45・46巡 | E1が旧V0札ID15・ID12で一致し、その使用札は回収時に消滅 |
| 47巡 | E1が最後の旧V0札ID19・B属性を設置。手札・山札からなくなっても場に1枚残る |
| 48巡終了 | 最後の旧V0札が回収され、全領域で0になる |

この例のP/V/E生カウンターとボス退場後のP/Vカウンターは集計CSVと一致した。札の効果は未実装なので、41巡や47巡の設置が実際にどの程度危険かは未評価。

### 11.6 ボス退場後の8巡

{post_table}

この8巡で新しいFを生成した条件・主体はなかった。上限24のPに見える約0.048%のFドローは、ボス生存中に生成済みの札の持越しであり、退場後の新規補填とは別。PのB生成は上限24・交代なしで244枚／1,000列、交代ありで60枚／1,000列。Vは全条件でB/F生成とFドローが0。

上限12・交代ありの8巡後は平均N24.242、うち消滅予定札0.242。Nが下限32未満でも、回収山から最低枚数を確保できればBを自動生成しない採用処理が働いている。「総量が下限へ戻らない」だけを循環不良とは判定しない。

ボス後に追加踏破をさせる価値は、残る危険、報酬、所要時間、選択肢によって決まる。この計測から追加踏破の楽しさや義務作業化を肯定・否定することはできない。

### 11.7 ここで終了する範囲と統合後に必要な確認

今回の承認済み札条件に対する、遭遇連続・偏在・補填・初期傾向・通常退場・継続ボス下の環境交代の検証は、統合へ返せる段階にある。条件を変えずに循環計算だけを増やす必要は現時点ではない。元の36条件に追加6条件を加えた42条件・42,000列だが、観測長が異なるため全条件を一つの確率へ合算しない。

| 次の判断 | 分類 | 統合時に確認すること |
|---|---|---|
| 遅い主体の受取上限と最低枚数 | 数値調整で改善が出た範囲 | 上限を抑えた条件を実際の手札・札効果へ接続し、借用する面白さまで失わないか |
| 長期の主体別構成 | 設計判断／必要ならルール再検討 | 構成が混ざることを探索の変化として使うか、育成した構成を維持したいか。後者なら通常再構築の配分等を改めて比較する |
| 穏やかな環境への交代 | 戦闘・環境設計との統合 | 新環境の本人能力と札効果を分け、旧札が残る6〜8巡前後にも踏破の手応えと判断の余地があるか。即時消去は現行退場規則の変更になる |
| 整理とボス後の踏破 | 面白さの実プレイ確認 | 弱札を使う／期限を待つ／旧札を借用する選択に局面ごとの見返りがあるか。進行だけのため毎回同じ処理を強いないか |
| 今回外の条件が採用された場合 | 新条件での再検証 | 同時複数敵、新環境の異なる初期量・期限、任意消滅効果、札効果が戦闘長を変える場合には、その仕様に絞って再実行する |

「面白い」と結論するには、再現局面へ戦闘側で承認された効果・能力を適用し、選択と結果の違いを評価する必要がある。本Workではその未確定値を勝手に埋めず、変更候補と試験局面を返す。Nの計数方法を戻す提案はしない。

追加資料：`followup.py`、`make_followup_report.py`、`source_metadata_followup.json`、`followup_results/summary.json`、`followup_results/trials.csv`（30,000行）、`followup_results/transitions.csv`（9,000行）、`followup_results/verification.json`、追加再現ログ1件。全試行の最終状態、各条件シード0の各行動を検査し、対照一致と再現ログ照合も確認した。
'''
    report_path = ROOT/'カード探索ゲーム_札循環検証.md'
    base = report_path.read_text().split(MARKER)[0].replace(NOTE,'').replace(REVIEW_NOTE,'')
    base = base.replace('位置づけ：', NOTE+'位置づけ：',1)
    review_path = ROOT/'design07_review.md'
    if review_path.exists():
        base = base.replace('位置づけ：',REVIEW_NOTE+'位置づけ：',1)
        appendix += '\n'+review_path.read_text()
    report_path.write_text(base.rstrip()+'\n'+appendix)

    readme_path = ROOT/'README.md'
    readme = readme_path.read_text().split('\n## 版0.6に対応した追加検証')[0]
    readme_path.write_text(readme.rstrip()+'''

## 版0.6に対応した追加検証

- followup.py：同じボスを残す環境交代あり／なし×環境上限6/12/24の6条件。最後にP/Vだけで8巡を観測。
- followup_results/summary.json：全6条件の定義と集計。
- followup_results/trials.csv：6条件×1,000シード×（生存中3主体＋退場後2主体）＝30,000行。
- followup_results/transitions.csv：交代あり3条件×1,000シード×3交代＝9,000行。
- followup_results/verification.json：対照の生カウンター一致、追加再現ログ照合。
- traces/boss_swap_cap12_seed0.json：継続ボスが旧環境札を使い続ける具体例。旧5ログと合わせて6件。
- source_metadata_followup.json：追加検証で参照した版0.6の情報。
- design07_review.md / source_metadata_review.json：版0.7の構造上の追加照合と参照情報。追加の数値実験ではない。
- make_followup_report.py：追加結果を報告書へ追記。繰り返し実行しても重複しない。
- カード探索ゲーム_札循環検証_統合用プロンプト.md：他Workの結果と統合する際の報告用プロンプト。

元の報告書を再作成するmake_report.pyは報告書・README・runtime.jsonを上書きします。追加検証まで再現する場合は、上記の元検証の後、次の順で実行してください。

```bash
python3 followup.py --seeds 1000
python3 followup.py --trace boss_swap_cap12 --seed 0 --out traces
python3 make_followup_report.py
```

ボス後の8巡は観測窓であり、正式な踏破所要時間ではありません。環境の穏やかさを決める札効果・能力は実装していません。
''')
    verification = {'control':'boss_hold_cap12 main_roles == persistent_enemy roles',
                    'control_equal':True,'replay':'boss_swap_cap12_seed0',
                    'replay_main_and_post_counters_equal':True,
                    'trials_rows':len(trials),'transition_rows':len(transitions)}
    (ROOT/'followup_results/verification.json').write_text(json.dumps(verification,indent=2))
    runtime = json.loads((ROOT/'runtime.json').read_text())
    runtime['code_sha256'] = {name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
                             for name in ('sim.py','test_sim.py','analyze.py','make_report.py',
                                          'followup.py','make_followup_report.py')}
    (ROOT/'runtime.json').write_text(json.dumps(runtime,indent=2))
    print('Appended design-0.6 report; control and replay checks passed.')


if __name__ == '__main__':
    main()
