#!/usr/bin/env python3
"""Card circulation experiment. Python standard library only. No combat utility model.

All real cards, including filler and departed-origin cards, contribute to N.
Run: python3 sim.py --seeds 1000 --out results
Replay: python3 sim.py --trace baseline --seed 0 --out traces
"""
from __future__ import annotations
import argparse, csv, itertools, json, random, sys, time
from collections import Counter
from dataclasses import dataclass, asdict, replace
from pathlib import Path

ROLES = ('P', 'V', 'E')  # player, environment, enemy

@dataclass(frozen=True)
class Config:
    name: str = 'baseline'
    encounters: int = 20
    rounds: int = 8
    gap: int = 2
    order: str = 'VPE'
    env_cap: int = 12
    min_multiplier: int = 1
    floor: int = 32
    deadline: int = 2
    affinity: tuple = (6, 2, 2, 2)
    recovery: str = 'random'
    basic_cap: int = 999
    player_policy: str = 'match'
    enemy_persists: bool = False
    enemy_alternates: bool = False
    env_period: int = 0

def configs():
    b = Config()
    out = [b]
    for order in itertools.permutations('PVE'):
        order = ''.join(order)
        if order != b.order:
            out.append(replace(b, name='order_'+order, order=order))
    for name, key, values in [
        ('env_cap','env_cap',(6,24)), ('minimum','min_multiplier',(2,)),
        ('floor','floor',(24,40)), ('deadline','deadline',(1,4)),
        ('length','rounds',(4,16)), ('gap','gap',(0,)),
        ('basic_cap','basic_cap',(1,)),
    ]:
        for v in values:
            out.append(replace(b, name=f'{name}_{v}', **{key:v}))
    out += [replace(b,name='fifo',recovery='fifo'),
            replace(b,name='affinity_9',affinity=(9,1,1,1)),
            replace(b,name='affinity_12',affinity=(12,0,0,0)),
            replace(b,name='expiry_first',player_policy='expiry'),
            replace(b,name='filler_first',player_policy='filler'),
            replace(b,name='persistent_enemy',gap=0,enemy_persists=True),
            replace(b,name='alternating_enemy',enemy_alternates=True),
            replace(b,name='environment_replacement',env_period=5)]
    # Targeted combinations of approved levels: isolate feedback and player-policy effects
    # after the environment's large private deck has produced measurable shortages.
    h=replace(b,env_cap=24)
    out += [replace(h,name='hoard_minimum_2',min_multiplier=2),
            replace(h,name='hoard_floor_24',floor=24),
            replace(h,name='hoard_floor_40',floor=40),
            replace(h,name='hoard_deadline_1',deadline=1),
            replace(h,name='hoard_deadline_4',deadline=4),
            replace(h,name='hoard_basic_cap_1',basic_cap=1),
            replace(h,name='hoard_filler_first',player_policy='filler'),
            replace(h,name='hoard_expiry_first',player_policy='expiry')]
    stress=replace(h,min_multiplier=2,floor=24,deadline=4)
    out += [replace(stress,name='combined_stress'),
            replace(stress,name='combined_stress_filler',player_policy='filler'),
            replace(stress,name='combined_stress_cap6',env_cap=6)]
    return out

@dataclass(slots=True)
class Card:
    id: int
    origin: str
    origin_role: str
    attr: int
    kind: str
    zone: str = ''
    owner: str = ''
    entered_round: int = 0
    entered_turn: int = 0
    remaining: int = 0
    dead: bool = False

class Actor:
    def __init__(self, uid, role, dom, cfg, seed):
        self.uid, self.role, self.dom = uid, role, dom
        self.hand_n = 1 if role == 'V' else 3
        self.minimum = self.hand_n * cfg.min_multiplier
        self.cap = cfg.env_cap if role == 'V' else 12
        assert self.minimum <= self.cap
        self.turn = 0
        self.deck, self.hand = [], []
        self.choose_rng = random.Random(f'{seed}:choice:{uid}')
        self.gen_rng = random.Random(f'{seed}:generation:{uid}')
        self.init_rng = random.Random(f'{seed}:initial:{uid}')
        self.rebuild_rng = random.Random(f'{seed}:rebuild:{uid}')

class Sim:
    def __init__(self, cfg, seed, trace=False, check=False):
        self.cfg, self.seed, self.trace, self.check = cfg, seed, trace, check
        self.pool, self.field = [], {}
        self.actors, self.all_actors, self.cards, self.retired = {}, {}, {}, {}
        self.n, self.next_id, self.round, self.tick, self.enc = 0, 0, 0, 0, 0
        self.live_kinds = Counter()
        self.stats = {r: Counter() for r in ROLES}
        self.enc_stats = [{r:Counter() for r in ROLES} for _ in range(cfg.encounters)]
        self.global_stats = Counter()
        self.hist = {}
        self.series, self.events = [], []
        self.round_stats = []
        self.pool_rng = random.Random(f'{seed}:pool')
        self.doomed_live = 0
        self.active_uid = None
        self.departures = []
        self.add_actor('P0','P',0)
        self.add_actor('V0','V',1)

    def inc(self, role, key, value=1):
        self.stats[role][key] += value
        self.enc_stats[self.enc][role][key] += value

    def add_hist(self, key, value):
        self.hist.setdefault(key,Counter())[value] += 1

    def label(self, c):
        return {'id':c.id,'origin':c.origin,'kind':c.kind,'attr':'ABCD'[c.attr],
                'remaining':c.remaining,'doomed':c.origin in self.retired}

    def state(self):
        return {'N':self.n,'filler':self.live_kinds['F'], 'doomed':self.doomed_live,
                'pool':len(self.pool),'field':len(self.field),
                'private':{r:{'id':a.uid,'hand':len(a.hand),'deck':len(a.deck),
                    'filler':sum(c.kind=='F' for c in a.hand+a.deck),
                    'doomed':sum(c.origin in self.retired for c in a.hand+a.deck)}
                    for r,a in self.actors.items()}}

    def log(self,event,**kw):
        if self.trace:
            self.events.append({'tick':self.tick,'round':self.round,'encounter':self.enc+1,
                                'event':event,**kw})

    def new_card(self, a, kind, attr):
        c=Card(self.next_id,a.uid,a.role,attr,kind)
        self.cards[c.id]=c
        self.next_id+=1
        self.n+=1
        self.live_kinds[kind]+=1
        return c

    def leave_zone(self,c):
        if c.zone in ('deck','hand'):
            a=self.all_actors[c.owner]
            elapsed=a.turn-c.entered_turn+(1 if c.zone=='hand' and self.active_uid==a.uid else 0)
            self.add_hist(f'{a.role}_{c.zone}_{c.kind}_completed',elapsed)
        elif c.zone=='field':
            self.add_hist(f'field_{c.kind}_completed',self.round-c.entered_round)
        c.zone=''

    def move(self,c,zone,a=None):
        self.leave_zone(c)
        c.zone=zone
        c.entered_round=self.round
        c.owner=a.uid if a else ''
        c.entered_turn=a.turn if a else 0

    def add_actor(self,uid,role,dom):
        a=Actor(uid,role,dom,self.cfg,self.seed)
        self.actors[role]=a
        self.all_actors[uid]=a
        attrs=[]
        for j,n in enumerate(self.cfg.affinity):
            attrs.extend([(dom+j)%4]*n)
        assert len(attrs)==12
        a.init_rng.shuffle(attrs)
        for attr in attrs:
            c=self.new_card(a,'I',attr)
            self.move(c,'deck',a)
            a.deck.append(c)
        self.global_stats['initial_created']+=12
        self.log('join',actor=uid,state=self.state(),deck=[self.label(c) for c in a.deck])

    def recover(self,c,reason):
        if c.kind=='F' or c.origin in self.retired:
            self.destroy(c,reason)
        else:
            self.move(c,'pool')
            self.pool.append(c)

    def destroy(self,c,reason):
        assert not c.dead
        self.leave_zone(c)
        if c.origin in self.retired:
            self.doomed_live-=1
            self.add_hist('departed_survival_completed',self.round-self.retired[c.origin])
        c.dead=True
        c.zone='dead'
        self.n-=1
        self.live_kinds[c.kind]-=1
        self.global_stats['destroyed']+=1
        self.global_stats['destroyed_'+c.kind]+=1
        self.log('destroy',card=self.label(c),reason=reason,N=self.n)

    def retire(self,role):
        a=self.actors[role]
        before=self.state()
        self.retired[a.uid]=self.round
        own=[c for c in self.cards.values() if not c.dead and c.origin==a.uid]
        self.doomed_live+=len(own)
        self.log('retire_begin',actor=a.uid,state=before)
        # Mark origin retired before returning private cards. Return foreign cards normally.
        private=a.hand+a.deck
        a.hand,a.deck=[],[]
        for c in private:
            self.recover(c,'holder_retired')
        old_pool=self.pool
        self.pool=[]
        for c in old_pool:
            if c.origin==a.uid:
                self.destroy(c,'origin_retired_in_pool')
            else:
                self.pool.append(c)
        del self.actors[role]
        remaining=sum(not c.dead and c.origin==a.uid for c in own)
        self.departures.append({'encounter':self.enc+1,'round':self.round,'role':role,
            'N_before':before['N'],'N_after':self.n,'immediate_loss':before['N']-self.n,
            'origin_remaining':remaining,'pool_after':len(self.pool)})
        self.log('retire_end',actor=a.uid,state=self.state(),origin_remaining=remaining)
        if self.check: self.validate()

    def rebuild(self,a):
        self.inc(a.role,'rebuilds')
        before=self.state()
        n_pool=len(self.pool)
        take=min(a.cap,n_pool)
        if self.cfg.recovery=='random':
            # Shuffle the pool then remove a uniform subset; remaining order is irrelevant.
            self.pool_rng.shuffle(self.pool)
        received=self.pool[:take]
        self.pool=self.pool[take:]
        need=max(0,a.minimum-take)
        deficit=max(0,self.cfg.floor-self.n)
        basics=min(need,deficit,self.cfg.basic_cap)
        fillers=need-basics
        if need:
            self.inc(a.role,'topup_events')
            if self.n>=self.cfg.floor:
                self.inc(a.role,'blocked_total_events')
                self.inc(a.role,'blocked_total_cards',need)
                live=[c for c in self.cards.values() if not c.dead]
                f=sum(c.kind=='F' for c in live)
                d=sum(c.origin in self.retired for c in live)
                u=sum(c.kind=='F' or c.origin in self.retired for c in live)
                # Diagnostic counters ONLY; none is used by the generation rule.
                if self.n-f<self.cfg.floor: self.inc(a.role,'filler_threshold_events')
                if self.n-d<self.cfg.floor: self.inc(a.role,'doomed_threshold_events')
                if self.n-u<self.cfg.floor: self.inc(a.role,'transient_threshold_events')
            self.inc(a.role,'generated_B',basics)
            self.inc(a.role,'generated_F',fillers)
        self.inc(a.role,'pool_received',take)
        self.inc(a.role,'rebuilt_received',take+need)
        for kind,count in [('B',basics),('F',fillers)]:
            for _ in range(count):
                j=a.gen_rng.choices(range(4),weights=self.cfg.affinity,k=1)[0]
                received.append(self.new_card(a,kind,(a.dom+j)%4))
        a.rebuild_rng.shuffle(received)
        for c in received:
            self.move(c,'deck',a)
        a.deck=received
        self.log('rebuild',actor=a.uid,before=before,pool_received=take,need=need,
            basic=basics,filler=fillers,after=self.state(),deck=[self.label(c) for c in a.deck])
        assert a.deck

    def action(self,role):
        a=self.actors[role]
        self.active_uid=a.uid
        self.tick+=1
        self.inc(role,'actions')
        drawn=[]
        while len(a.hand)<a.hand_n:
            if not a.deck: self.rebuild(a)
            c=a.deck.pop(0)
            self.move(c,'hand',a)
            c.remaining=self.cfg.deadline
            a.hand.append(c)
            drawn.append(c)
            self.inc(role,'draws')
            self.inc(role,'draw_'+c.kind)
            self.inc(role,'attr_'+str(c.attr))
            self.inc(role,'source_'+c.origin_role)
            if c.origin==a.uid: self.inc(role,'draw_own_origin')
            if c.attr==a.dom: self.inc(role,'draw_dominant')
            if c.origin in self.retired: self.inc(role,'draw_doomed')
        matches=[c for c in a.hand if c.attr in self.field]
        policy=self.cfg.player_policy if role=='P' else 'match'
        if policy=='match':
            candidates=matches or a.hand
        elif policy=='expiry':
            rem=min(c.remaining for c in a.hand)
            candidates=[c for c in a.hand if c.remaining==rem]
        elif policy=='filler':
            candidates=[c for c in a.hand if c.kind=='F']
            if not candidates: candidates=matches or a.hand
        else: raise ValueError(policy)
        c=a.choose_rng.choice(candidates)
        if matches: self.inc(role,'match_available')
        if any(x.kind=='F' for x in a.hand): self.inc(role,'filler_in_hand_actions')
        if all(x.kind=='F' for x in a.hand): self.inc(role,'all_filler_actions')
        if len({x.attr for x in a.hand})>=2: self.inc(role,'multiple_attributes_actions')
        matched=c.attr in self.field
        if matches and not matched: self.inc(role,'foregone_match')
        if c.kind=='F':
            self.inc(role,'used_F')
            if matches and not matched: self.inc(role,'filler_foregone_match')
            if any(x.kind!='F' for x in matches): self.inc(role,'filler_over_nonfiller_match')
        if self.trace:
            self.log('play',actor=a.uid,drawn=[self.label(x) for x in drawn],
                hand=[self.label(x) for x in a.hand],field=[self.label(x) for x in self.field.values()],
                chosen=self.label(c),matched=matched,state=self.state())
        a.hand.remove(c)
        if matched:
            self.inc(role,'matches')
            self.inc(role,'match_'+c.kind)
            other=self.field.pop(c.attr)
            self.recover(c,'matched_play')
            self.recover(other,'matched_field')
        else:
            self.move(c,'field')
            self.field[c.attr]=c
        remaining=[]
        for c in a.hand:
            c.remaining-=1
            if c.remaining<=0:
                self.inc(role,'expired')
                self.inc(role,'expired_'+c.kind)
                self.recover(c,'expired')
            else: remaining.append(c)
        a.hand=remaining
        a.turn+=1
        self.active_uid=None
        if self.trace: self.log('action_end',actor=a.uid,state=self.state())
        if self.check: self.validate()

    def play_round(self,combat):
        self.round+=1
        for role in self.cfg.order:
            if role in self.actors and (combat or role!='E'):
                self.action(role)
        g=self.global_stats
        g['rounds']+=1
        g['N_sum']+=self.n
        g['F_sum']+=self.live_kinds['F']
        g['doomed_sum']+=self.doomed_live
        g['pool_sum']+=len(self.pool)
        g['zero_pool_rounds']+=not self.pool
        g['below_floor_rounds']+=self.n<self.cfg.floor
        g['N_min']=min(g.get('N_min',self.n),self.n)
        g['N_max']=max(g.get('N_max',self.n),self.n)
        g['F_max']=max(g['F_max'],self.live_kinds['F'])
        for role,a in self.actors.items():
            self.inc(role,'private_stock_sum',len(a.hand)+len(a.deck))
            self.inc(role,'private_stock_samples')
        self.round_stats.append((self.enc+1,self.round,int(combat),self.n,self.live_kinds['F'],len(self.pool)))

    def validate(self):
        zones=self.pool+list(self.field.values())
        for a in self.actors.values(): zones+=a.hand+a.deck
        assert len(zones)==len({c.id for c in zones})==self.n
        alive=[c for c in self.cards.values() if not c.dead]
        assert {c.id for c in alive}=={c.id for c in zones}
        assert Counter(c.kind for c in alive)==+self.live_kinds
        assert self.doomed_live==sum(c.origin in self.retired for c in alive)
        assert all(c.kind!='F' and c.origin not in self.retired for c in self.pool)
        assert len(self.field)<=4
        for attr,c in self.field.items(): assert attr==c.attr and c.zone=='field'
        for a in self.actors.values():
            assert len(a.hand)<=a.hand_n
            assert len(a.deck)<=max(12,a.cap)
            assert all(c.owner==a.uid and c.zone=='hand' and c.remaining>0 for c in a.hand)
            assert all(c.owner==a.uid and c.zone=='deck' for c in a.deck)

    def run(self):
        for enc in range(self.cfg.encounters):
            self.enc=enc
            if 'E' not in self.actors:
                dom=2+(enc%2) if self.cfg.enemy_alternates else 2
                self.add_actor(f'E{enc+1}','E',dom)
            for _ in range(self.cfg.rounds): self.play_round(True)
            self.series.append({'encounter':enc+1,'stage':'pre_retirement',**self.state()})
            if not self.cfg.enemy_persists or enc==self.cfg.encounters-1: self.retire('E')
            if self.cfg.env_period and (enc+1)%self.cfg.env_period==0 and enc<self.cfg.encounters-1:
                self.retire('V')
                self.add_actor(f'V{enc+1}','V',1)
            self.series.append({'encounter':enc+1,'stage':'post_retirement',**self.state()})
            if enc<self.cfg.encounters-1:
                for _ in range(self.cfg.gap): self.play_round(False)
            self.series.append({'encounter':enc+1,'stage':'segment_end',**self.state()})
        for c in self.cards.values():
            if c.dead: continue
            if c.zone in ('hand','deck'):
                a=self.all_actors[c.owner]
                age=a.turn-c.entered_turn
                self.add_hist(f'{a.role}_{c.zone}_{c.kind}_censored',age)
            elif c.zone=='field':
                self.add_hist(f'field_{c.kind}_censored',self.round-c.entered_round)
            if c.origin in self.retired:
                self.add_hist('departed_survival_censored',self.round-self.retired[c.origin])
        self.validate()
        created=self.global_stats['initial_created']+sum(s['generated_B']+s['generated_F'] for s in self.stats.values())
        assert self.n==created-self.global_stats['destroyed']
        assert sum(s['actions']-2*s['matches'] for s in self.stats.values())==len(self.field)
        self.global_stats.update({'N_final':self.n,'F_final':self.live_kinds['F'],
            'B_final':self.live_kinds['B'],'doomed_final':self.doomed_live})
        self.log('end',state=self.state())
        return self

def ratio(a,b): return a/b if b else 0.0

def trial_row(s,role):
    c=s.stats[role]
    row={'condition':s.cfg.name,'seed':s.seed,'role':role,**dict(c)}
    for label,lo,hi in [('early',0,5),('late',s.cfg.encounters-5,s.cfg.encounters)]:
        counts=Counter()
        for e in s.enc_stats[lo:hi]: counts.update(e[role])
        for key in ['draws','draw_F','draw_own_origin','draw_dominant','attr_0','attr_1','attr_2','attr_3','source_P','source_V','source_E','generated_B','generated_F','actions','matches']:
            row[label+'_'+key]=counts[key]
    row['filler_draw_rate']=ratio(c['draw_F'],c['draws'])
    row['topup_event_rate']=ratio(c['topup_events'],c['rebuilds'])
    row['generated_share']=ratio(c['generated_B']+c['generated_F'],c['rebuilt_received'])
    row['match_rate']=ratio(c['matches'],c['actions'])
    row['late_dominant_rate']=ratio(row['late_draw_dominant'],row['late_draws'])
    return row

def run_suite(selected,seeds,out):
    out.mkdir(parents=True,exist_ok=True)
    summaries={}
    rows=[]
    for cfg in selected:
        t=time.time()
        aggregate={r:Counter() for r in ROLES}
        enc=[{r:Counter() for r in ROLES} for _ in range(cfg.encounters)]
        global_stats=Counter()
        hists={}
        series={}
        departure_sums={}
        for seed in range(seeds):
            s=Sim(cfg,seed,check=seed==0).run()
            for r in ROLES:
                aggregate[r].update(s.stats[r])
                rows.append(trial_row(s,r))
            for i,e in enumerate(s.enc_stats):
                for r in ROLES: enc[i][r].update(e[r])
            global_stats.update(s.global_stats)
            for k,h in s.hist.items(): hists.setdefault(k,Counter()).update(h)
            for p in s.series:
                key=str(p['encounter'])+'_'+p['stage']
                z=series.setdefault(key,Counter())
                for k in ['N','filler','doomed','pool','field']: z[k]+=p[k]
            for p in s.departures:
                key=str(p['encounter'])+'_'+p['role']
                z=departure_sums.setdefault(key,Counter())
                for k in ['N_before','N_after','immediate_loss','origin_remaining','pool_after']: z[k]+=p[k]
        summaries[cfg.name]={'config':asdict(cfg),'seeds':seeds,'roles':aggregate,
            'encounters':enc,'global_sums':global_stats,'histograms':hists,
            'series_sums':series,'departure_sums':departure_sums}
        print(f'{cfg.name}: {seeds} seeds, {time.time()-t:.1f}s; P filler {ratio(aggregate["P"]["draw_F"],aggregate["P"]["draws"]):.4%}',flush=True)
        (out/'summary.json').write_text(json.dumps(summaries,ensure_ascii=False,indent=2),encoding='utf-8')
    fields=['condition','seed','role']+sorted(set().union(*(r.keys() for r in rows))-{'condition','seed','role'})
    with (out/'trials.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields,restval=0)
        w.writeheader();w.writerows(rows)
    (out/'configs.json').write_text(json.dumps([asdict(c) for c in selected],indent=2),encoding='utf-8')

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--seeds',type=int,default=1000)
    p.add_argument('--out',type=Path,default=Path('results'))
    p.add_argument('--conditions',nargs='*')
    p.add_argument('--trace')
    p.add_argument('--seed',type=int,default=0)
    args=p.parse_args()
    all_cfg={c.name:c for c in configs()}
    if args.trace:
        s=Sim(all_cfg[args.trace],args.seed,trace=True,check=True).run()
        args.out.mkdir(parents=True,exist_ok=True)
        path=args.out/f'{args.trace}_seed{args.seed}.json'
        path.write_text(json.dumps({'config':asdict(s.cfg),'seed':s.seed,'events':s.events,
            'stats':s.stats,'rounds':s.round_stats},ensure_ascii=False,indent=2),encoding='utf-8')
        print(path)
    else:
        selected=[all_cfg[k] for k in args.conditions] if args.conditions else list(all_cfg.values())
        run_suite(selected,args.seeds,args.out)

if __name__=='__main__': main()
