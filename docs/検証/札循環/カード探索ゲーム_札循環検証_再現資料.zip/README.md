# 札循環検証の再現資料

正本を変更しない検証用資料です。結果の解釈は「カード探索ゲーム_札循環検証.md」を参照。

## ファイル

- sim.py：承認されたルールと36比較条件。シミュレーションはPython標準ライブラリのみ。
- test_sim.py：総量・出現元・期限などのルール確認6件。
- results/configs.json：全36条件の完全なパラメータ。
- results/trials.csv：36条件×1,000シード×3主体＝108,000行。件数・比率・初期5遭遇／終盤5遭遇のカウント。
- results/summary.json：条件別・主体別・遭遇別集計、期間ヒストグラム、退場時系列。
- analysis/metrics.csv, metrics.json：主体別の導出指標。
- analysis/encounters.csv：全条件・全遭遇・全主体の属性構成と補填札率。
- analysis/detail.json：主要条件の分布と滞留。completedは観測中に終了、censoredは観測打切り。
- traces/*.json：問題例を含む5試行の全行動ログ。I=初期札、B=基本札、F=補填専用札。P=プレイヤー、V=環境、E=敵。
- circulation_overview.png：比較図。英字の主体・属性は上記の略記と対応。
- source_metadata.json：参照正本の版・日時。
- runtime.json：作成時のPythonバージョンとコードSHA-256。

## 再実行

このフォルダを作業ディレクトリとして実行します。

```bash
python3 -m unittest -v test_sim.py
python3 sim.py --seeds 1000 --out results
python3 analyze.py
```

図・日本語報告書の再作成にはmatplotlibとnumpyが必要です。作成環境のバージョンはruntime.jsonに記録。

```bash
python3 make_report.py
```

特定の問題例の再現：

```bash
python3 sim.py --trace env_cap_24 --seed 463 --out traces
python3 sim.py --trace hoard_minimum_2 --seed 733 --out traces
python3 sim.py --trace combined_stress --seed 49 --out traces
python3 sim.py --trace hoard_floor_40 --seed 3 --out traces
python3 sim.py --trace baseline --seed 0 --out traces
```

属性・札効果や相手の行動を最適化する戦闘シミュレーターではありません。弱札率や一致率を戦闘勝率・面白さの指標と同一視しないでください。

## 版0.6に対応した追加検証

- followup.py：同じボスを残す環境交代あり／なし×環境上限6/12/24の6条件。最後にP/Vだけで8巡を観測。
- followup_results/summary.json：全6条件の定義と集計。
- followup_results/trials.csv：6条件×1,000シード×（生存中3主体＋退場後2主体）＝30,000行。
- followup_results/transitions.csv：交代あり3条件×1,000シード×3交代＝9,000行。
- followup_results/verification.json：対照の生カウンター一致、追加再現ログ照合。
- traces/boss_swap_cap12_seed0.json：継続ボスが旧環境札を使い続ける具体例。旧5ログと合わせて6件。
- source_metadata_followup.json：追加検証で参照した版0.6の情報。
- design07_review.md / source_metadata_review.json：版0.7の構造上の追加照合と参照情報。追加の数値実験ではない。
- make_followup_report.py：追加結果を報告書へ追記。繰り返し実行しても重複しない。
- カード探索ゲーム_札循環検証_統合用プロンプト.md：他Workの結果と統合する際の報告用プロンプト。

元の報告書を再作成するmake_report.pyは報告書・README・runtime.jsonを上書きします。追加検証まで再現する場合は、上記の元検証の後、次の順で実行してください。

```bash
python3 followup.py --seeds 1000
python3 followup.py --trace boss_swap_cap12 --seed 0 --out traces
python3 make_followup_report.py
```

ボス後の8巡は観測窓であり、正式な踏破所要時間ではありません。環境の穏やかさを決める札効果・能力は実装していません。
