"""Bounded counterfactual diagnostics for two traversal-event exits.

The three cases are fixed in input.json before execution. This is a one-action
calculator check, not a generic event engine or a new encounter rollout.
"""
from __future__ import annotations

import copy
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PROBE = ROOT.parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(PROBE))
from action_preview_trial.data_review import predict


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def legal(scene):
    rows = []
    for card in scene["hand"]:
        targets = [a for a in ("E", "V") if scene["actors"][a]["active"]] if card["kind"] == "attack" and card["attr"] in scene["field"] else [None]
        rows.extend({"card_id": card["id"], "target": target} for target in targets)
    return rows


def separate_calculation(scene, choice):
    """Separate small calculation specialized to the declared 12 legal options.

    Matching defense and defended targets are intentionally unsupported here;
    assertions fail if a later condition silently broadens this trial.
    """
    card = next(c for c in scene["hand"] if c["id"] == choice["card_id"])
    material = scene["field"].get(card["attr"])
    target = choice["target"]
    actor = scene["actors"]["P"]
    matched = material is not None
    assert actor["guard"] is None
    critical = actor["crit"] + (actor["crit_gain"] if matched else 0)
    damage = 0
    actual_loss = 0
    hit_total = None
    hit_connected = None
    target_hp = None
    target_hit = None
    if matched:
        assert card["kind"] == "attack" and target in ("E", "V")
        victim = scene["actors"][target]
        assert victim["guard"] is None
        hit_total = sum((victim["hit"], card["hit"], material["field_hit"]))
        hit_connected = hit_total >= 100
        target_hp, target_hit = victim["hp"], hit_total
        if hit_connected:
            critical_multiplier, _ = divmod(critical, 100)
            hit_multiplier, _ = divmod(hit_total, 100)
            damage = max(0, (card["power"] + material["field_power"]) * (1 + critical_multiplier) * (1 + hit_multiplier))
            actual_loss = min(victim["hp"], damage)
            target_hp -= actual_loss
            target_hit = 0
            if critical >= 100:
                critical = 0
    else:
        assert target is None
    return {
        "mode": "attack" if matched else "place",
        "matched_id": material["id"] if matched else None,
        "damage": damage,
        "actual_hp_loss": actual_loss,
        "hit_connected": hit_connected,
        "hit_total": hit_total,
        "target_hp_after": target_hp,
        "target_hit_after": target_hit,
        "P_crit_after": critical,
        "P_hp_after": actor["hp"],
        "expired_ids": [c["id"] for c in scene["hand"] if c["id"] != card["id"] and c["remaining"] <= 1],
        "applied_cost": card["match_cost"] if matched else card["place_cost"],
    }


def public_projection(prediction):
    row = {k: prediction[k] for k in ("mode", "matched_id", "damage", "actual_hp_loss", "hit_connected", "hit_total", "expired_ids", "applied_cost")}
    victim = prediction["target_after"]
    row.update(target_hp_after=victim["hp"] if victim else None,
               target_hit_after=victim["hit"] if victim else None,
               P_crit_after=prediction["self_after"]["crit"],
               P_hp_after=prediction["self_after"]["hp"])
    return row


def main():
    input_path = ROOT / "input.json"
    input_hash = sha(input_path)
    spec = json.loads(input_path.read_text(encoding="utf-8"))
    source_path = PROBE / spec["source"]["file"]
    original_data = json.loads(source_path.read_text(encoding="utf-8"))
    source = next(s for s in original_data["scenes"] if s["id"] == spec["source"]["scene_id"])
    base = {k: copy.deepcopy(source[k]) for k in ("id", "time", "actors", "field", "hand")}
    save(ROOT / "source_public_A98.json", base)
    before = json.dumps(base, sort_keys=True)
    assert len(spec["cases"]) == 3
    assert [c["type"] for c in base["hand"]] == ["l", "r", "f"]
    assert base["actors"]["P"]["crit"] == 100
    cases = []
    for config in spec["cases"]:
        scene = copy.deepcopy(base)
        for target, override in config["overrides"].items():
            assert target in ("E", "V") and set(override) == {"hp", "hit"}
            scene["actors"][target].update(override)
        rows = []
        choices = legal(scene)
        assert len(choices) == 4
        for choice in choices:
            calculation = separate_calculation(scene, choice)
            existing = public_projection(predict(scene, choice))
            assert calculation == existing, (config["id"], choice, calculation, existing)
            resolved = None
            if calculation["target_hp_after"] == 0:
                resolved = "obstacle_destroyed" if choice["target"] == "E" else "detour_completed"
            card = next(c for c in scene["hand"] if c["id"] == choice["card_id"])
            rows.append({**choice, "card_name": card["name"], **calculation,
                         "selected_condition_after_current_action": resolved,
                         "event_transition_executed": False,
                         "reward_evaluated": False})
        cases.append({"id": config["id"], "title": config["title"],
                      "counterfactual_overrides": config["overrides"],
                      "all_legal_options": rows})
        assert json.dumps(base, sort_keys=True) == before
    completions = {c["id"]: [r["selected_condition_after_current_action"] for r in c["all_legal_options"] if r["selected_condition_after_current_action"]] for c in cases}
    assert completions == {
        "obstacle_opening": ["obstacle_destroyed"],
        "detour_opening": ["detour_completed"],
        "no_immediate_route_distinction": ["obstacle_destroyed", "detour_completed"],
    }
    assert input_hash == sha(input_path), "declared trial input changed during run"
    summary = {
        "status": spec["status"],
        "method": "事前固定した未到達証明の3差替え条件・全12合法手。公開予測と別式を照合。今回の解決条件判定まで",
        "source_file_sha256": sha(source_path),
        "input_file_sha256": input_hash,
        "source_snapshot_sha256": sha(ROOT / "source_public_A98.json"),
        "calculator_sha256": sha(PROBE / "action_preview_trial/data_review.py"),
        "program_sha256": sha(Path(__file__)),
        "source_reached_status": "元の A98 は到達確認済み。HP・命中度を差し替えた3条件は初期状態からの到達未確認",
        "old_engine_event_reward_execution_count": 0,
        "NPC_actions_executed": 0,
        "condition_count": len(cases),
        "legal_option_count": sum(len(c["all_legal_options"]) for c in cases),
        "independent_calculations_matched": True,
        "source_unchanged": True,
        "cases": cases,
        "limitations": spec["explicit_limits"],
    }
    save(ROOT / "results.json", summary)
    print(json.dumps({"conditions": 3, "legal_options": 12, "checks_passed": True, "completions": completions}, ensure_ascii=False))


if __name__ == "__main__":
    main()
