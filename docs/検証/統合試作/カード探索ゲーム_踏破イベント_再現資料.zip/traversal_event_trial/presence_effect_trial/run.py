"""Five fixed, hand-built presence-effect states; all 30 one-action choices.

This independent diagnostic applies only the arithmetic declared in input.json.
It does not run the existing encounter engine or execute any event transition.
"""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def apply_overrides(common, overrides):
    state = copy.deepcopy(common)
    for path, value in overrides.items():
        parts = path.split(".")
        parent = state
        for part in parts[:-1]:
            parent = parent[part]
        assert parts[-1] in parent
        parent[parts[-1]] = value
    return state


def calculate(state, card, target_id):
    target = state["targets"][target_id]
    matching = [c for c in state["field"] if c["attribute"] == card["attribute"]]
    assert len(matching) == 1
    material = matching[0]
    assert material["power_modifier"] == material["hit_modifier"] == 0
    assert target["exists"] and target["hp"] > 0
    presence = state["presence_support"]
    support_active = state["targets"][presence["source"]]["exists"]
    evasion = presence["evasion_reduction_of_current_gain"] if support_active and target_id == presence["recipient"] else 0
    gain = card["hit"] - evasion
    assert gain > 0, "zero/negative gain is outside the declared trial"
    total = target["hit_meter"] + gain
    critical = state["P"]["crit"] + state["P"]["crit_gain_on_match"]
    connected = total >= 100
    am = 1 + critical // 100
    hm = 1 + total // 100 if connected else None
    damage = max(0, (card["power"] * am - target["persistent_reduction"]) * hm) if connected else 0
    actual_loss = min(target["hp"], damage)
    remaining_hp = target["hp"] - actual_loss
    condition = ("obstacle_destroyed" if target_id == "O" else "detour_completed") if remaining_hp == 0 else None
    return {
        "card_id": card["id"], "card_name": card["name"], "target_id": target_id,
        "matched_material": material["id"], "power": card["power"], "card_hit": card["hit"],
        "target_HP_before": target["hp"], "target_hit_meter_before": target["hit_meter"],
        "persistent_reduction": target["persistent_reduction"], "evasion_subtracted": evasion,
        "hit_gain": gain, "hit_total_before_reset": total, "hit_connected": connected,
        "attack_crit_multiplier": am, "hit_multiplier": hm, "damage": damage,
        "actual_HP_loss": actual_loss, "target_HP_after": remaining_hp,
        "target_hit_meter_after": 0 if connected else total,
        "P_crit_before": state["P"]["crit"], "P_crit_after_matching": critical,
        "P_crit_after_action": 0 if connected and critical >= 100 else critical,
        "P_critical_consumed": connected and critical >= 100,
        "applied_cost": card["match_cost"],
        "unplayed_hand": [{"card_id": c["id"], "life_before": c["remaining_life"], "life_after": c["remaining_life"] - 1} for c in state["cards"] if c["id"] != card["id"]],
        "expired_cards": [c["id"] for c in state["cards"] if c["id"] != card["id"] and c["remaining_life"] <= 1],
        "condition_satisfied": condition,
        "event_transition_executed": False,
    }


def main():
    path = ROOT / "input.json"
    input_hash = digest(path)
    data = json.loads(path.read_text(encoding="utf-8"))
    ids = [c["id"] for c in data["conditions"]]
    assert ids == ["baseline", "without_evasion_support", "P_crit_200", "V_meter_90", "O_hp_8"]
    cards = data["common"]["cards"]
    assert [c["id"] for c in cards] == ["heavy", "precise", "standard"]
    assert len({c["attribute"] for c in cards}) == 3
    assert all(c["remaining_life"] == 2 and c["match_cost"] == 12 for c in cards)
    before = json.dumps(data, sort_keys=True)
    cases = []
    baseline = None
    for condition in data["conditions"]:
        state = apply_overrides(data["common"], condition["overrides"])
        choices = [calculate(state, card, target) for card in state["cards"] for target in ("O", "V")]
        if baseline is None:
            baseline = choices
        for row, base in zip(choices, baseline):
            assert (row["card_id"], row["target_id"]) == (base["card_id"], base["target_id"])
            row["differences_from_baseline"] = {key: {"before": base[key], "after": value} for key, value in row.items() if key != "differences_from_baseline" and value != base[key]}
        cases.append({"id": condition["id"], "name": condition["name"], "overrides": condition["overrides"], "all_legal_actions": choices,
                      "completing_choices": [{"card_id": r["card_id"], "target_id": r["target_id"], "condition": r["condition_satisfied"]} for r in choices if r["condition_satisfied"]]})
    # Hand-calculated fixtures, independently written before executing this code.
    # Entries are heavy O/V, precise O/V, standard O/V in that fixed order.
    expected_damage = {
        "baseline": [24, 0, 0, 16, 8, 0],
        "without_evasion_support": [24, 0, 0, 16, 8, 24],
        "P_crit_200": [104, 0, 32, 48, 56, 0],
        "V_meter_90": [24, 40, 0, 16, 8, 24],
        "O_hp_8": [24, 0, 0, 16, 8, 0],
    }
    expected_connections = {
        "baseline": [True, False, True, True, True, False],
        "without_evasion_support": [True, False, True, True, True, True],
        "P_crit_200": [True, False, True, True, True, False],
        "V_meter_90": [True, True, True, True, True, True],
        "O_hp_8": [True, False, True, True, True, False],
    }
    for case in cases:
        rows = case["all_legal_actions"]
        assert [r["damage"] for r in rows] == expected_damage[case["id"]]
        assert [r["hit_connected"] for r in rows] == expected_connections[case["id"]]
        assert all(r["expired_cards"] == [] for r in rows)
        assert all(h["life_after"] == 1 for r in rows for h in r["unplayed_hand"])
        assert all(r["target_HP_after"] >= 0 for r in rows)
        assert all(r["target_hit_meter_after"] == 0 for r in rows if r["hit_connected"])
        assert all(r["P_crit_after_action"] == (0 if r["hit_connected"] else 250) for r in rows) if case["id"] == "P_crit_200" else all(r["P_crit_after_action"] == 50 for r in rows)
    assert before == json.dumps(data, sort_keys=True)
    assert digest(path) == input_hash
    result = {
        "status": data["status"], "reached_status": data["reached_status"],
        "input_sha256": input_hash, "program_sha256": digest(Path(__file__)),
        "case_count": len(cases), "legal_action_count": sum(len(c["all_legal_actions"]) for c in cases),
        "integer_arithmetic": True, "manual_damage_and_hit_checks_passed": True,
        "only_current_action": True, "engine_or_NPC_actions_executed": 0,
        "event_transitions_executed": 0, "reward_evaluation_performed": False,
        "cases": cases, "excluded": data["excluded"],
    }
    (ROOT / "results.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"cases": 5, "legal_actions": 30, "checks_passed": True,
                      "completing_choices": {c["id"]: c["completing_choices"] for c in cases}}, ensure_ascii=False))


if __name__ == "__main__":
    main()
