"""Fixed 20-branch light-source diagnostic through the enemy's first action.

Only the small temporary event outcomes in input.json are supported. This is
not a generic encounter/event/circulation implementation or a game policy.
"""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def overrides(base, changes):
    result = copy.deepcopy(base)
    for path, value in changes.items():
        parts = path.split(".")
        parent = result
        for part in parts[:-1]:
            parent = parent[part]
        assert parts[-1] in parent
        parent[parts[-1]] = value
    return result


class Trial:
    def __init__(self, data):
        self.s = copy.deepcopy(data)
        self.now = 0
        self.log = []
        self.actions = []
        self.ended = None
        for card in self.s["cards"].values():
            card.update(doomed=False, destroyed=False)
        self.check()

    def log_event(self, kind, **values):
        self.log.append({"type": kind, "time": self.now, **copy.deepcopy(values)})

    def queue(self):
        entries = [{"actor": who, "time": actor["next_at"]} for who, actor in self.s["actors"].items() if actor["active"] and actor["hp"] > 0 and actor["next_at"] is not None]
        assert len({x["time"] for x in entries}) == len(entries), "same-time order is not in this trial"
        return sorted(entries, key=lambda r: r["time"])

    def check(self):
        locations = [cid for actor in self.s["actors"].values() for cid in actor["hand"]]
        locations += list(self.s["field"].values()) + self.s["pool"] + self.s["destroyed"]
        assert sorted(locations) == sorted(self.s["cards"])
        assert len(locations) == len(set(locations))
        for cid, card in self.s["cards"].items():
            assert card["destroyed"] == (cid in self.s["destroyed"])
        for who, actor in self.s["actors"].items():
            if not actor["active"]:
                assert actor["next_at"] is None

    def recover(self, cid, reason):
        card = self.s["cards"][cid]
        assert not card["destroyed"] and cid not in self.s["pool"]
        card["remaining_life"] = None
        if card["doomed"]:
            card["destroyed"] = True
            self.s["destroyed"].append(cid)
            self.log_event("destroy_on_recovery", card_id=cid, origin=card["origin"], reason=reason)
        else:
            self.s["pool"].append(cid)
            self.log_event("recover", card_id=cid, origin=card["origin"], reason=reason)

    def retire(self, who, event):
        actor = self.s["actors"][who]
        assert actor["hp"] == 0 and who in ("E", "L")
        self.log_event("selected_trial_event", event=event, departing_actor=who)
        actor["active"], actor["next_at"] = False, None
        for cid, card in self.s["cards"].items():
            if card["origin"] == who and not card["destroyed"]:
                card["doomed"] = True
                self.log_event("mark_origin_doomed", card_id=cid, origin=who)
        for cid in list(self.s["pool"]):
            if self.s["cards"][cid]["origin"] == who:
                self.s["pool"].remove(cid)
                self.recover(cid, "origin_departed_while_in_pool")
        for cid in list(actor["hand"]):
            actor["hand"].remove(cid)
            self.recover(cid, "retiring_holder_releases_hand")
        self.log_event("retire", actor=who, field=copy.deepcopy(self.s["field"]), pool=self.s["pool"], destroyed=self.s["destroyed"])
        if who == "E":
            self.ended = "enemy_defeated_observation_end"

    def play(self, who, cid, target):
        assert self.ended is None
        actor = self.s["actors"][who]
        victim = self.s["actors"][target]
        assert actor["active"] and victim["active"] and actor["hp"] > 0 and victim["hp"] > 0
        assert cid in actor["hand"]
        assert self.queue()[0]["actor"] == who
        self.now = actor["next_at"]
        actor["next_at"] = None  # The current actor is removed from the wait queue.
        card = self.s["cards"][cid]
        actor["hand"].remove(cid)
        material = self.s["field"].get(card["attribute"])
        before = {a: {k: v[k] for k in ("hp", "hit", "crit", "active")} for a, v in self.s["actors"].items()}
        connected = None
        total = None
        damage = 0
        actual_loss = 0
        support = self.s["presence_effect"]["hit_gain_to_every_current_attack"] if self.s["actors"]["L"]["active"] else 0
        if material:
            del self.s["field"][card["attribute"]]
            actor["crit"] += actor["crit_gain"]
            total = victim["hit"] + card["hit"] + support
            victim["hit"] = total
            connected = total >= 100
            if connected:
                damage = card["power"] * (1 + actor["crit"] // 100) * (1 + total // 100)
                actual_loss = min(victim["hp"], damage)
                victim["hp"] -= actual_loss
                victim["hit"] = 0
                if actor["crit"] >= 100:
                    actor["crit"] = 0
            mode = "attack"
        else:
            self.s["field"][card["attribute"]] = cid
            card["remaining_life"] = None
            mode = "place"
        self.log_event("effect", actor=who, card_id=cid, target=target if material else None,
                       mode=mode, material=material, support_applied=support if material else 0,
                       hit_total=total, hit_connected=connected, damage=damage, actual_HP_loss=actual_loss)
        if material:
            self.recover(cid, "played_card")
            self.recover(material, "matched_material")
        expired = []
        for held_id in list(actor["hand"]):
            held = self.s["cards"][held_id]
            life_before = held["remaining_life"]
            held["remaining_life"] -= 1
            self.log_event("hand_age", actor=who, card_id=held_id, before=life_before, after=held["remaining_life"])
            if held["remaining_life"] <= 0:
                actor["hand"].remove(held_id)
                self.recover(held_id, "hand_expired")
                expired.append(held_id)
        # Each supported attack has one target and no reactive damage: no
        # simultaneous outcome is silently ordered by this diagnostic.
        newly_zero = [a for a, v in self.s["actors"].items() if v["active"] and v["hp"] == 0]
        assert len(newly_zero) <= 1
        event = None
        if newly_zero:
            defeated = newly_zero[0]
            if defeated == "L":
                event = "light_extinguished"
                self.retire("L", event)
            elif defeated == "E":
                event = "enemy_defeated"
                self.retire("E", event)
            else:
                event = "player_defeated"
                self.log_event("selected_trial_event", event=event, departing_actor="P", note="P死亡と予約失効まで。探索死亡後処理は対象外")
                self.s["actors"]["P"]["active"] = False
                self.s["actors"]["P"]["next_at"] = None
                self.ended = "player_defeated_observation_end"
        if actor["active"] and actor["hp"] > 0:
            actor["next_at"] = self.now + self.s["action_cost"]
            self.log_event("reinsert", actor=who, next_at=actor["next_at"])
        self.check()
        self.actions.append({"actor": who, "time": self.now, "card_id": cid,
                             "target": target if material else None, "mode": mode,
                             "material": material, "presence_bonus_applied": support if material else 0,
                             "hit_total": total, "hit_connected": connected, "damage": damage,
                             "actual_HP_loss": actual_loss, "expired": expired,
                             "selected_trial_event": event, "actors_before": before,
                             "actors_after": {a: {k: v[k] for k in ("hp", "hit", "crit", "active", "next_at")} for a, v in self.s["actors"].items()},
                             "queue_after": self.queue()})

    def output(self):
        return {"time": self.now, "observation_end": self.ended or "after_E_action_before_L6",
                "actors": self.s["actors"], "L_present": self.s["actors"]["L"]["active"],
                "P_alive": self.s["actors"]["P"]["hp"] > 0,
                "field": self.s["field"], "pool": self.s["pool"], "destroyed": self.s["destroyed"],
                "cards": self.s["cards"], "remaining_queue": self.queue(),
                "actions": self.actions, "trace": self.log,
                "represented_card_count": len(self.s["cards"]) - len(self.s["destroyed"]),
                "global_N_rescue_or_rebuild_executed": False,
                "reward_or_next_event_generation_executed": False}


def main():
    input_path = ROOT / "input.json"
    input_hash = sha(input_path)
    spec = json.loads(input_path.read_text(encoding="utf-8"))
    before = json.dumps(spec, sort_keys=True)
    assert [c["id"] for c in spec["conditions"]] == ["baseline", "enemy_near_defeat", "enemy_low_hit", "deny_enemy_material", "enemy_hits_without_light"]
    assert spec["P_choices"] == [{"card_id": c, "target": t} for c in ("H", "Q") for t in ("E", "L")]
    cases = []
    for condition in spec["conditions"]:
        state = overrides(spec["common"], condition["overrides"])
        branches = []
        for choice in spec["P_choices"]:
            trial = Trial(state)
            trial.play("P", choice["card_id"], choice["target"])
            if trial.ended is None:
                assert trial.s["actors"]["E"]["active"] and trial.queue()[0] == {"actor": "E", "time": 4}
                trial.play("E", "E_attack", "P")
            out = trial.output()
            assert not any(a["actor"] == "L" for a in out["actions"])
            assert sum(a["actor"] == "P" for a in out["actions"]) == 1
            assert all(out["cards"][cid]["remaining_life"] == 1 for cid in out["actors"]["P"]["hand"])
            if choice["target"] == "L":
                assert not out["L_present"]
                assert out["cards"]["material_C"]["doomed"]
                retirement = next(e for e in out["trace"] if e["type"] == "retire" and e["actor"] == "L")
                assert retirement["field"]["C"] == "material_C" and "material_C" not in retirement["destroyed"]
                if state["cards"]["E_attack"]["attribute"] == "C":
                    assert "material_C" in out["destroyed"]
                else:
                    assert out["field"]["C"] == "material_C" and "material_C" not in out["destroyed"]
            branches.append({"P_choice": choice, "end": out})
        cases.append({"id": condition["id"], "name": condition["name"], "overrides": condition["overrides"], "branches": branches})
    # Independent hand-calculated outcome fixtures, fixed before the first run.
    expected = {
        "baseline": [(0,10,True,"attack",True),(14,30,False,"attack",False),(0,18,True,"attack",True),(14,30,False,"attack",False)],
        "enemy_near_defeat": [(14,0,True,None,None),(14,20,False,"attack",False),(0,8,True,"attack",True),(14,20,False,"attack",False)],
        "enemy_low_hit": [(14,10,True,"attack",False),(14,30,False,"attack",False),(14,18,True,"attack",False),(14,30,False,"attack",False)],
        "deny_enemy_material": [(14,10,True,"place",None),(14,30,False,"place",None),(0,18,True,"attack",True),(14,30,False,"attack",False)],
        "enemy_hits_without_light": [(0,10,True,"attack",True),(0,30,False,"attack",True),(0,18,True,"attack",True),(0,30,False,"attack",True)],
    }
    for case in cases:
        actual = []
        for branch in case["branches"]:
            end = branch["end"]
            e_action = next((a for a in end["actions"] if a["actor"] == "E"), None)
            actual.append((end["actors"]["P"]["hp"], end["actors"]["E"]["hp"], end["L_present"], e_action["mode"] if e_action else None, e_action["hit_connected"] if e_action else None))
        assert actual == expected[case["id"]], (case["id"], actual)
    assert before == json.dumps(spec, sort_keys=True) and sha(input_path) == input_hash
    result = {"status": spec["status"], "reached_status": spec["reached_status"],
              "input_sha256": input_hash, "program_sha256": sha(Path(__file__)),
              "condition_count": 5, "branch_count": 20, "manual_outcome_checks_passed": True,
              "card_location_checks_passed": True, "light_material_delayed_destruction_checks_passed": True,
              "L_actions_executed": 0, "global_N_rescue_executed": False,
              "probabilities_or_optimal_policy_estimated": False, "cases": cases,
              "limits": [spec["horizon"], spec["circulation_limit"], *spec["excluded"]]}
    (ROOT / "results.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"conditions": 5, "branches": 20, "checks_passed": True,
                      "P_survival_by_choice_HE_HL_QE_QL": {c["id"]: [b["end"]["P_alive"] for b in c["branches"]] for c in cases}}, ensure_ascii=False))


if __name__ == "__main__":
    main()
