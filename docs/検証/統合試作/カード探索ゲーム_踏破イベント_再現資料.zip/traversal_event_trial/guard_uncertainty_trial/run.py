"""Finite, predeclared guard/light diagnostic. No policy or probability model."""
from __future__ import annotations
import copy
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def overrides(base, changes):
    s = copy.deepcopy(base)
    for path, value in changes.items():
        parts = path.split(".")
        parent = s
        for part in parts[:-1]:
            parent = parent[part]
        assert parts[-1] in parent
        parent[parts[-1]] = value
    return s


class Trial:
    def __init__(self, data):
        self.s = copy.deepcopy(data)
        self.now, self.ended = 0, None
        self.trace, self.actions = [], []
        for c in self.s["cards"].values():
            c.update(doomed=False, destroyed=False)
        self.check()

    def log(self, kind, **values):
        self.trace.append({"type": kind, "time": self.now, **copy.deepcopy(values)})

    def queue(self):
        q = [{"actor": a, "time": v["next_at"]} for a,v in self.s["actors"].items()
             if v["active"] and v["hp"] > 0 and v["next_at"] is not None]
        assert len({v["time"] for v in q}) == len(q), "same-time ordering is outside this trial"
        return sorted(q, key=lambda v: v["time"])

    def check(self):
        locations = [c for a in self.s["actors"].values() for zone in ("hand", "deck") for c in a[zone]]
        locations += list(self.s["field"].values()) + self.s["pool"] + self.s["destroyed"]
        assert sorted(locations) == sorted(self.s["cards"])
        assert len(locations) == len(set(locations))
        for cid,c in self.s["cards"].items():
            assert c["destroyed"] == (cid in self.s["destroyed"])
        for actor in self.s["actors"].values():
            if not actor["active"]:
                assert actor["next_at"] is None
            if actor["guard"]:
                assert actor["guard"]["uses"] > 0

    def recover(self, cid, reason):
        card = self.s["cards"][cid]
        assert not card["destroyed"] and cid not in self.s["pool"]
        card["remaining_life"] = None
        if card["doomed"]:
            card["destroyed"] = True
            self.s["destroyed"].append(cid)
            self.log("destroy_on_recovery", card_id=cid, origin=card["origin"], reason=reason)
        else:
            self.s["pool"].append(cid)
            self.log("recover", card_id=cid, origin=card["origin"], reason=reason)

    def refill(self, who):
        actor = self.s["actors"][who]
        assert self.queue()[0]["actor"] == who and self.ended is None
        self.now = actor["next_at"]
        while len(actor["hand"]) < actor["hand_limit"]:
            assert actor["deck"], "No rebuild or generated replacement is implemented"
            cid = actor["deck"].pop(0)
            actor["hand"].append(cid)
            self.s["cards"][cid]["remaining_life"] = self.s["cards"][cid]["life"]
            self.log("draw", actor=who, card_id=cid, remaining_life=self.s["cards"][cid]["life"])
        self.check()

    def retire(self, who, event):
        a = self.s["actors"][who]
        assert who in ("E", "L") and a["hp"] == 0
        self.log("selected_trial_event", event=event, departing_actor=who)
        a["active"], a["next_at"] = False, None
        for cid,c in self.s["cards"].items():
            if c["origin"] == who and not c["destroyed"]:
                c["doomed"] = True
                self.log("mark_origin_doomed", card_id=cid, origin=who)
        for cid in list(self.s["pool"]):
            if self.s["cards"][cid]["origin"] == who:
                self.s["pool"].remove(cid)
                self.recover(cid, "origin_departed_while_in_pool")
        for zone in ("hand", "deck"):
            for cid in list(a[zone]):
                a[zone].remove(cid)
                self.recover(cid, "retiring_holder_releases_" + zone)
        self.log("retire", actor=who, field=self.s["field"], pool=self.s["pool"], destroyed=self.s["destroyed"])
        if who == "E":
            self.ended = "enemy_defeated_observation_end"

    def play(self, who, cid, target=None):
        assert self.ended is None and self.queue()[0]["actor"] == who
        a = self.s["actors"][who]
        assert a["active"] and a["hp"] > 0 and cid in a["hand"]
        self.now, a["next_at"] = a["next_at"], None
        a["hand"].remove(cid)
        c = self.s["cards"][cid]
        material = self.s["field"].get(c["attribute"])
        before = copy.deepcopy(self.s["actors"])
        support = self.s["presence_effect"]["hit_gain_to_every_current_attack"] if self.s["actors"]["L"]["active"] else 0
        hit_total, connected, damage, actual_loss = None, None, 0, 0
        attack_multiplier, defense_multiplier, hit_multiplier = None, None, None
        guard_applied = None
        effective_target = target if material else None
        if material:
            del self.s["field"][c["attribute"]]
            if a["guard"]:
                self.log("guard_ends_on_own_match", actor=who, previous_guard=a["guard"])
                a["guard"] = None
            a["crit"] += a["crit_gain"]
            if c["kind"] == "guard":
                assert target == who
                mode = "guard"
                a["guard"] = {"value": c["value"], "uses": c["uses"], "source_card": cid}
            else:
                mode = "attack"
                assert target in self.s["actors"] and target != who
                v = self.s["actors"][target]
                assert v["active"] and v["hp"] > 0
                hit_total = v["hit"] + c["hit"] + support
                v["hit"] = hit_total
                connected = hit_total >= 100
                if connected:
                    attack_multiplier = 1 + a["crit"] // 100
                    hit_multiplier = 1 + hit_total // 100
                    defense = 0
                    if v["guard"]:
                        guard_applied = copy.deepcopy(v["guard"])
                        defense_multiplier = 1 + v["crit"] // 100
                        defense = v["guard"]["value"] * defense_multiplier
                        v["guard"]["uses"] -= 1
                        self.log("guard_applied", actor=target, value=defense, remaining_uses=v["guard"]["uses"], crit_added=0)
                        if v["guard"]["uses"] == 0:
                            v["guard"] = None
                        if v["crit"] >= 100:
                            v["crit"] = 0
                    damage = max(0, (c["power"] * attack_multiplier - defense) * hit_multiplier)
                    actual_loss = min(v["hp"], damage)
                    v["hp"] -= actual_loss
                    v["hit"] = 0
                    if a["crit"] >= 100:
                        a["crit"] = 0
        else:
            mode = "place"
            self.s["field"][c["attribute"]] = cid
            c["remaining_life"] = None
        public_effect = {"actor": who, "card_id": cid, "card_attribute": c["attribute"], "target": effective_target,
                         "mode": mode, "material": material, "support_applied": support if mode == "attack" else 0,
                         "hit_total": hit_total, "hit_connected": connected, "damage": damage, "actual_HP_loss": actual_loss,
                         "attack_crit_multiplier": attack_multiplier, "defense_crit_multiplier": defense_multiplier,
                         "hit_multiplier": hit_multiplier, "guard_applied": guard_applied}
        self.log("effect", **public_effect)
        if material:
            self.recover(cid, "played_card")
            self.recover(material, "matched_material")
        expired = []
        for held_id in list(a["hand"]):
            held = self.s["cards"][held_id]
            old = held["remaining_life"]
            held["remaining_life"] -= 1
            self.log("hand_age", actor=who, card_id=held_id, before=old, after=held["remaining_life"])
            if held["remaining_life"] <= 0:
                a["hand"].remove(held_id)
                self.recover(held_id, "hand_expired")
                expired.append(held_id)
        zero = [x for x,v in self.s["actors"].items() if v["active"] and v["hp"] == 0]
        assert len(zero) <= 1, "simultaneous results are not tested"
        event = None
        if zero:
            dead = zero[0]
            if dead in ("E", "L"):
                event = "enemy_defeated" if dead == "E" else "light_extinguished"
                self.retire(dead, event)
            else:
                event = "player_defeated"
                self.log("selected_trial_event", event=event, departing_actor="P", note="死亡と予約失効のみ")
                self.s["actors"]["P"]["active"], self.s["actors"]["P"]["next_at"] = False, None
                self.ended = "player_defeated_observation_end"
        if a["active"] and a["hp"] > 0:
            a["next_at"] = self.now + self.s["action_cost"]
            self.log("reinsert", actor=who, next_at=a["next_at"])
        self.check()
        self.actions.append({"time": self.now, **public_effect, "expired": expired, "selected_trial_event": event,
                             "actors_before": before, "actors_after": copy.deepcopy(self.s["actors"]), "queue_after": self.queue()})

    def public_state(self):
        # No deck card IDs or enemy future card definitions are included.
        actors = {who: {k: copy.deepcopy(a[k]) for k in ("hp", "hit", "crit", "guard", "active", "next_at")}
                  for who,a in self.s["actors"].items()}
        for who,a in self.s["actors"].items():
            actors[who].update(hand_count=len(a["hand"]), deck_count=len(a["deck"]))
        public_cards = set(self.s["actors"]["P"]["hand"] + list(self.s["field"].values()) + self.s["pool"] + self.s["destroyed"])
        history = [copy.deepcopy(e) for e in self.trace if e["type"] == "effect"]
        public_cards.update(e["card_id"] for e in history)
        assert "E_next" not in public_cards
        return {"time": self.now, "actors": actors, "P_hand": self.s["actors"]["P"]["hand"].copy(),
                "cards_visible_now_or_already_played": {cid: copy.deepcopy(self.s["cards"][cid]) for cid in sorted(public_cards)},
                "field": copy.deepcopy(self.s["field"]), "pool": self.s["pool"].copy(), "destroyed": self.s["destroyed"].copy(),
                "queue": self.queue(), "observed_actions": history}

    def legal_P_choices(self):
        choices = []
        for cid in self.s["actors"]["P"]["hand"]:
            c = self.s["cards"][cid]
            if c["attribute"] not in self.s["field"]:
                choices.append({"card_id": cid, "target": None})
            elif c["kind"] == "guard":
                choices.append({"card_id": cid, "target": "P"})
            else:
                choices += [{"card_id": cid, "target": who} for who in ("E", "L") if self.s["actors"][who]["active"]]
        return choices

    def output(self, horizon):
        return {"observation_end": self.ended or horizon, "time": self.now, "P_alive": self.s["actors"]["P"]["hp"] > 0,
                "actors": copy.deepcopy(self.s["actors"]), "field": copy.deepcopy(self.s["field"]),
                "pool": self.s["pool"].copy(), "destroyed": self.s["destroyed"].copy(), "cards": copy.deepcopy(self.s["cards"]),
                "remaining_queue": self.queue(), "represented_card_count": len(self.s["cards"])-len(self.s["destroyed"]),
                "actions": copy.deepcopy(self.actions), "trace": copy.deepcopy(self.trace)}


def state_B(spec, world):
    s = copy.deepcopy(spec["common"])
    b = spec["trial_B"]
    s["actors"]["P"]["hp"] = world["P_HP"]
    s["cards"].update(copy.deepcopy(b["added_cards"]))
    loc = b["initial_locations"]
    for who in ("P", "E", "L"):
        for zone in ("hand", "deck"):
            s["actors"][who][zone] = copy.deepcopy(loc[who+"_"+zone])
    types = {v["id"]: v for v in b["enemy_types"]}
    for cid, key in (("E_attack", "first_enemy"), ("E_next", "next_enemy")):
        t = types[world[key]]
        s["cards"][cid].update(attribute=t["attribute"], hit=t["hit"])
    s["cards"]["F"]["attribute"] = world["draw_attribute"]
    return s


def ending_summary(out):
    a = out["actors"]
    last_e = next((v for v in reversed(out["actions"]) if v["actor"] == "E" and v["time"] == 16), None)
    return {"P_HP": a["P"]["hp"], "P_alive": a["P"]["hp"] > 0, "E_HP": a["E"]["hp"],
            "E_defeated": not a["E"]["active"], "L_present": a["L"]["active"],
            "P_hit": a["P"]["hit"], "P_crit": a["P"]["crit"], "P_guard": copy.deepcopy(a["P"]["guard"]),
            "E_hit": a["E"]["hit"], "E_crit": a["E"]["crit"],
            "E16_mode": last_e["mode"] if last_e else None, "E16_damage": last_e["damage"] if last_e else 0,
            "E16_connected": last_e["hit_connected"] if last_e else None,
            "P12_expired": next((v["expired"] for v in out["actions"] if v["actor"] == "P" and v["time"] == 12), []),
            "field_attributes": sorted(out["field"]), "remaining_queue": out["remaining_queue"]}


def check_A(cases):
    # Independent scalar fixtures: unguarded first E attack either deals 16 or misses/places.
    fixtures = {
        "baseline": [(16,10,True),(0,30,False),(16,18,True),(0,30,False),(10,30,True)],
        "enemy_near_defeat": [(0,0,True),(0,20,False),(16,8,True),(0,20,False),(10,20,True)],
        "enemy_low_hit": [(0,10,True),(0,30,False),(0,18,True),(0,30,False),(0,30,True)],
        "deny_enemy_material": [(0,10,True),(0,30,False),(16,18,True),(0,30,False),(10,30,True)],
        "enemy_hits_without_light": [(16,10,True),(16,30,False),(16,18,True),(16,30,False),(10,30,True)],
    }
    for case in cases:
        for branch, (loss,ehp,lit) in zip(case["branches"], fixtures[case["id"]]):
            end = branch["end"]
            assert (end["actors"]["P"]["hp"],end["actors"]["E"]["hp"],end["actors"]["L"]["active"]) == (max(0,case["P_initial_HP"]-loss),ehp,lit)
        guard = case["branches"][-1]["end"]
        p = guard["actors"]["P"]
        low = case["id"] == "enemy_low_hit"
        assert p["crit"] == 50 and p["hit"] == (60 if low else 0)
        assert (p["guard"] is not None) == low


def check_B(worlds):
    # Independent reviewer hand-calculated these complete survivor signatures
    # before the simulation's first run. C/F here denotes the P refill attribute.
    fixtures = {
      "C60": {"HE":"1111","HL":"1111","QE":"1101","QL":"1111","FC":"0100","FF":"1101"},
      "C100":{"HE":"1111","HL":"1111","QE":"1101","QL":"1111","FC":"0100","FF":"1101"},
      "C20": {"HE":"1111","HL":"1111","QE":"1101","QL":"1101","FC":"0000","FF":"1101"},
      "A60": {"H":"0100","QE":"0110","QL":"1110","FC":"1111","FF":"0110"},
    }
    order = ["C60","C20","A60","C100"]
    for world in worlds:
        setting = world["setting"]
        first, next_type = setting["first_enemy"], setting["next_enemy"]
        hp_before = setting["P_HP"] - (0 if first == "C20" else 10)
        for branch in world["branches"]:
            choice, out = branch["P12_choice"], branch["end"]
            cid, target = choice["card_id"], choice["target"]
            if cid == "F":
                key = "F" + setting["draw_attribute"]
            else:
                key = cid + (target or "")
            survives = fixtures[first][key][order.index(next_type)] == "1"
            assert out["P_alive"] == survives, (setting, choice, ending_summary(out))
            assert out["actors"]["P"]["hp"] == (hp_before if survives else 0)
            if cid == "H" and target == "E":
                assert not out["actors"]["E"]["active"]
                assert out["actors"]["E"]["hp"] == 0
                assert not any(a["time"] == 16 for a in out["actions"])
                assert "E_next" in out["destroyed"]
            if target == "L":
                if cid in ("H", "Q"):
                    assert not out["actors"]["L"]["active"]
                    # L already placed N. Retirement marks it but does not remove it.
                    assert out["field"]["E"] == "N" and out["cards"]["N"]["doomed"]
                    assert "N" not in out["destroyed"]
            expected_expired = [c for c in ("H","Q") if c != cid]
            p12 = next(a for a in out["actions"] if a["actor"] == "P" and a["time"] == 12)
            assert p12["expired"] == expected_expired
            if first == "C20" and cid == "F" and setting["draw_attribute"] == "C":
                last_e = next(a for a in out["actions"] if a["actor"] == "E" and a["time"] == 16)
                assert last_e["damage"] == (39 if next_type == "C100" else 26)
                assert last_e["guard_applied"] is not None


def main():
    spec_path = ROOT / "input.json"
    input_hash = sha(spec_path)
    spec = json.loads(spec_path.read_text(encoding="utf-8"))
    before = canonical(spec)
    cases = []
    for hp in spec["trial_A"]["HP_values"]:
        for condition in spec["trial_A"]["conditions"]:
            state = overrides(spec["common"], condition["overrides"])
            state["actors"]["P"]["hp"] = hp
            branches = []
            for choice in spec["trial_A"]["P_choices"]:
                trial = Trial(state)
                trial.play("P", choice["card_id"], choice["target"])
                if trial.ended is None:
                    trial.play("E", "E_attack", "P")
                branches.append({"P_choice":choice,"end":trial.output("after_E4_before_L6")})
            cases.append({"id": condition["id"], "P_initial_HP": hp, "branches": branches})
    assert sum(len(c["branches"]) for c in cases) == 50
    check_A(cases)
    worlds, groups = [], {}
    assert len(spec["trial_B"]["worlds"]) == 64
    for world in spec["trial_B"]["worlds"]:
        trial = Trial(state_B(spec, world))
        trial.play("P", "G", "P")
        trial.play("E", "E_attack", "P")
        assert trial.ended is None and trial.queue()[0] == {"actor":"L","time":6}
        trial.play("L", "N", None)
        assert trial.queue()[0] == {"actor":"P","time":12}
        trial.refill("P")
        assert [trial.s["cards"][c]["remaining_life"] for c in ("H","Q","F")] == [1,1,2]
        public = trial.public_state()
        group_id = hashlib.sha256(canonical(public).encode()).hexdigest()[:16]
        if group_id not in groups:
            groups[group_id] = {"public_state_id":group_id,"public_state":public,"choices":{},"worlds":[]}
        group = groups[group_id]
        assert canonical(group["public_state"]) == canonical(public)
        group["worlds"].append(world["id"])
        branches = []
        for choice in trial.legal_P_choices():
            branch = copy.deepcopy(trial)
            branch.play("P",choice["card_id"],choice["target"])
            if branch.ended is None:
                assert branch.queue()[0] == {"actor":"E","time":16}
                branch.refill("E")
                branch.play("E","E_next","P")
            out = branch.output("after_E16_before_L18_and_P24")
            branches.append({"P12_choice":choice,"end":out})
            key = canonical(choice)
            item = group["choices"].setdefault(key,{"P12_choice":choice,"outcomes_by_hidden_next_card":[]})
            item["outcomes_by_hidden_next_card"].append({"hidden_next_type_for_analysis_only":world["next_enemy"], **ending_summary(out)})
        worlds.append({"setting":world,"public_state_id":group_id,"branches":branches})
    check_B(worlds)
    for group in groups.values():
        assert len(group["worlds"]) == 4
        for item in group["choices"].values():
            outs = item["outcomes_by_hidden_next_card"]
            assert [v["hidden_next_type_for_analysis_only"] for v in outs] == ["C60","C20","A60","C100"]
            item["outcome_set"] = {"P_HP_min":min(v["P_HP"] for v in outs),"P_HP_max":max(v["P_HP"] for v in outs),
                "P_survives_all_four_tested_cards":all(v["P_alive"] for v in outs),
                "P_alive_results":sorted({v["P_alive"] for v in outs}),
                "E_defeated_results":sorted({v["E_defeated"] for v in outs}),
                "L_present_results":sorted({v["L_present"] for v in outs}),
                "E16_modes":sorted({v["E16_mode"] or "not_executed" for v in outs})}
        group["choices"] = list(group["choices"].values())
    assert len(groups) == 16
    assert before == canonical(spec) and sha(spec_path) == input_hash
    result = {"status":spec["status"],"input_sha256":input_hash,"program_sha256":sha(Path(__file__)),
        "counts":{"A_conditions":10,"A_branches":50,"B_worlds":64,"B_public_states":16,"B_branches":sum(len(w["branches"]) for w in worlds)},
        "checks":{"A_manual_endpoints":True,"B_independent_manual_survival_and_HP":True,"card_conservation_and_retirement":True,
                  "public_group_same_across_four_hidden_cards":True,"unused_H_Q_expire_at_P12":True},
        "probabilities_or_optimal_policy_estimated":False,"global_N_rescue_or_rebuild_executed":False,
        "A_cases":cases,"B_public_groups":list(groups.values()),"B_worlds":worlds,
        "limits":[spec["reached_status"],spec["resource_scope"],*spec["excluded"]]}
    (ROOT / "results.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({"counts":result["counts"],"checks":result["checks"],"input_sha256":input_hash},ensure_ascii=False))


if __name__ == "__main__":
    main()
