"""Reaggregate existing B results; no turn simulation or policy selection."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def current_information(public):
    card_ids = set(public["P_hand"] + list(public["field"].values()))
    visible = public["cards_visible_now_or_already_played"]
    return {
        "time": public["time"],
        "actors": public["actors"],
        "P_hand": public["P_hand"],
        "field": public["field"],
        "current_cards": {cid: visible[cid] for cid in sorted(card_ids)},
        "queue": public["queue"],
    }


def outcome_signature(group):
    return sorted(
        (canonical(choice["P12_choice"]), canonical(choice["outcome_set"]))
        for choice in group["choices"]
    )


def main():
    source_path = ROOT / "results.json"
    source_hash = sha(source_path)
    source = json.loads(source_path.read_text(encoding="utf-8"))
    original_groups = source["B_public_groups"]
    merged = {}
    for group in original_groups:
        public = current_information(group["public_state"])
        assert "E_next" not in canonical(public)
        key = canonical(public)
        item = merged.setdefault(key, {"current_information": public, "groups": []})
        item["groups"].append(group)

    reviewed = []
    for key, item in merged.items():
        groups = item["groups"]
        reference = outcome_signature(groups[0])
        assert all(outcome_signature(group) == reference for group in groups)
        reviewed.append({
            "current_information_id": hashlib.sha256(key.encode()).hexdigest()[:16],
            "current_information": item["current_information"],
            "source_public_group_ids": [group["public_state_id"] for group in groups],
            "source_world_ids_for_traceability_only": [
                world for group in groups for world in group["worlds"]
            ],
            "same_action_outcome_summaries_equal": True,
            "action_outcome_summaries": [
                {"P12_choice": json.loads(action), "outcome_set": json.loads(outcomes)}
                for action, outcomes in reference
            ],
        })

    assert len(original_groups) == 16 and len(reviewed) == 12
    assert sum(len(group["source_public_group_ids"]) == 2 for group in reviewed) == 4
    assert sha(source_path) == source_hash
    result = {
        "status": "既存B結果の再集約のみ。追加の局面・行動実行・方策選択なし。",
        "source_results_sha256": source_hash,
        "review_program_sha256": sha(Path(__file__)),
        "grouping_keys": {
            "time": "P12時点の時刻",
            "actors": "各主体のHP・命中度・会心度・防御・生存・次回予約・手札枚数・山札枚数。元のpublic_state内actorsを保持。",
            "P_hand": "自分の現在手札IDと順序",
            "field": "現在の属性と場札IDの対応",
            "current_cards": "現在の自手札または場にある札の、元のpublic_stateに含まれる全情報。過去に使われただけの札は含めない。",
            "queue": "現在の既知待機列",
        },
        "excluded_from_grouping": [
            "公開済み行動履歴",
            "回収山・消滅札の一覧と、その領域だけにある札の詳細",
            "敵の次札E_nextの属性・命中等",
            "試験世界IDや条件名",
        ],
        "comparison_scope": {
            "match_key": "同じP12_choice（札ID・対象）の集合も含めて一致すること",
            "compared_outcome_set_fields": [
                "P_HP_min", "P_HP_max", "P_survives_all_four_tested_cards",
                "P_alive_results", "E_defeated_results", "L_present_results", "E16_modes",
            ],
            "not_compared_as_equivalent": "完全な事後状態・完全履歴・各隠れ札別の一対一結果を同一とした検査ではない。元結果に保存済みの各手の有限結果要約を比較。",
        },
        "counts": {
            "original_B_public_groups": len(original_groups),
            "current_information_groups": len(reviewed),
            "groups_merging_two_original_groups": 4,
            "unchanged_single_groups": 8,
        },
        "checks": {
            "next_enemy_card_absent_from_grouping": True,
            "all_merged_same_action_outcome_summaries_equal": True,
            "source_results_unchanged": True,
        },
        "interpretation": "今回の有限比較では、全履歴や回収・消滅札の詳細を分類に使わなくても、各手の結果要約は変わらない。製品の公開範囲や最小UIを確定するものではない。",
        "limits": [
            "敵の全候補札を網羅していない。4型への生存を未知札全体への安全保証にしない。",
            "確率・勝率・期待値・人の読み取り・通常プレイからの到達を評価しない。",
            "比較した手の存在と、プレイヤーがその安全性を把握できることは別。",
        ],
        "groups": reviewed,
    }
    output_path = ROOT / "review_public_groups.json"
    output_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"counts": result["counts"], "checks": result["checks"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
