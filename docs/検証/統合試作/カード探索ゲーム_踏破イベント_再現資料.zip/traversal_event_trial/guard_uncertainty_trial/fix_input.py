"""Build the predeclared finite conditions; no simulation or outcome search."""
import copy
import hashlib
import itertools
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
prior = ROOT.parent / "light_source_trial"
old = json.loads((prior / "input.json").read_text(encoding="utf-8"))
common = copy.deepcopy(old["common"])
for who, actor in common["actors"].items():
    actor["deck"] = []
    actor["hand_limit"] = 3 if who == "P" else 1
    actor["guard"] = None
common["actors"]["P"]["hand"] = ["H", "Q", "G"]
for c in common["cards"].values():
    c["kind"] = "attack"
common["cards"]["G"] = {"name": "能動防御", "kind": "guard", "attribute": "D", "power": 0, "hit": 0,
    "value": 3, "uses": 1, "life": 2, "remaining_life": 2, "origin": "P"}
common["cards"]["material_D"] = {"name": "中立材料D", "kind": "attack", "attribute": "D", "power": 0, "hit": 0,
    "life": 2, "remaining_life": None, "origin": "P"}
common["field"]["D"] = "material_D"
types = [{"id": "C60", "attribute": "C", "hit": 60}, {"id": "C20", "attribute": "C", "hit": 20},
         {"id": "A60", "attribute": "A", "hit": 60}, {"id": "C100", "attribute": "C", "hit": 100}]
added = {
  "F": {"name": "補充した弱攻撃", "kind": "attack", "attribute": "C", "power": 2, "hit": 50, "life": 2, "remaining_life": None, "origin": "P"},
  "N": {"name": "光源の中立札", "kind": "attack", "attribute": "E", "power": 0, "hit": 0, "life": 2, "remaining_life": 2, "origin": "L"},
  "E_next": {"name": "敵の次回固定攻撃", "kind": "attack", "attribute": "C", "power": 8, "hit": 60, "life": 2, "remaining_life": None, "origin": "E"},
}
choices = copy.deepcopy(old["P_choices"]) + [{"card_id": "G", "target": "P"}]
spec = {
  "status": "事前固定の診断用仮設定。能力・数値・敵判断・後続札を正式採用しない。",
  "scope": "防御を含めると光源への対処が非公開敵札の正解当てだけになるかを、有限の結果集合として診断する。",
  "fixed_before_run": "AはHP2×既存敵5条件×全5手=50枝。BはHP2×初回敵4×P補充属性2×独立した次回敵4=64世界を最初の実行前に固定。B各世界で次Pの全合法手を列挙。検索・乱数・結果による世界の追加なし。",
  "reached_status": "手製局面。初期構築からの到達・通常の手札頻度・不可避性は未検証。",
  "previous_input_sha256": hashlib.sha256((prior / "input.json").read_bytes()).hexdigest(),
  "common": common,
  "trial_A": {
    "HP_values": [14, 24], "conditions": old["conditions"], "P_choices": choices,
    "horizon": "P0の全5手と、生存EのE4まで。L6未実行。両者の山札は空として明記し、その先を扱わない。",
  },
  "trial_B": {
    "HP_values": [14, 24], "enemy_types": types, "draw_attributes": ["C", "F"],
    "added_cards": added,
    "initial_locations": {"P_hand": ["H", "Q", "G"], "P_deck": ["F"], "E_hand": ["E_attack"], "E_deck": ["E_next"], "L_hand": ["N"], "L_deck": []},
    "worlds": [{"id": f"hp{hp}_{first['id']}_draw{attr}_next{second['id']}", "P_HP": hp, "first_enemy": first["id"], "draw_attribute": attr, "next_enemy": second["id"]}
               for hp, first, attr, second in itertools.product([14,24], types, ["C","F"], types)],
    "horizon": "P0防御→E4→L6中立E設置→P12→E16まで。E撃破またはP死亡はその記録まで。",
    "P0_choice": {"card_id": "G", "target": "P"},
    "L6_choice": {"card_id": "N", "target": None},
    "P12_refill": "H/Qを保持、山札先頭Fを1枚引き手札3へ補充。Fの属性C/Fは事前因子で、P12の時点で公開されている。H/Q残期限1、F残期限2。",
    "P12_choices": "手札から全合法手。属性一致のある攻撃札は生存E/Lをそれぞれ対象にする。不一致は対象を選ばない設置1手。自由パスなし。",
    "E16_refill": "手札規定1に対し固定E_nextを1枚補充。初回札から独立に4型を比較し、P12では非公開。型の出現確率や敵の性格は設定しない。",
    "public_grouping": "P12時点の自手札・HP・対象別命中度・共用会心・防御・場・既知待機列・回収札/消滅札・公開済みP0/E4/L6履歴・山札枚数のみで分類する。E_nextの属性/命中等をキーへ含めず、同じ公開状態と同じP12手について4型を横断集計。履歴から次の札が同型と推定しない。",
    "why_second_draw_attribute": "初回EがAを消費した後、補充F属性Cで残る敵C材料も必ず消せる答えを補充側で保証した対照だけにしない。F属性Fは同性能だが初期場にFなし。",
  },
  "formula": {
    "matching": "同属性材料があれば一致必須。一致時のみ会心+50。材料効果は全札0。設置では会心増加なし。",
    "hit": old["formula"]["hit"],
    "temporary_hit_multiplier": "命中なら1+floor(total/100)。これは既存試作の仮式であり採用仕様ではない。",
    "damage": "命中時 max(0,(札power*(1+floor(攻撃会心/100)) - 有効な防御value*(1+floor(防御会心/100)))*(1+floor(total/100)))。HPを0で下止め。",
    "guard": "Gの一致で防御value3/uses1を起動。自身の次の一致で既存防御を終了し、新防御なら置換（置換は試行仮処理）。不一致設置では保持。命中への適用で1回消費、被害0でも消費。未命中では消費せず、実防御時の会心加算なし。防御会心100以上なら命中を実防御した時に発動・0へ。",
    "reset": old["formula"]["reset"],
  },
  "action_resolution": old["action_resolution"],
  "trial_event_results": {
    **old["trial_event_results"],
    "retirement_held_cards": "E/Lの実退場では本人の手札と山札を全て回収処理。由来札は消滅予定、回収山内の由来札はその場で消滅。場の由来札は退場だけでは消滅しない。",
  },
  "resource_scope": "A8枚/B11枚の全所在を明記し、必要ドロー・期限・回収・由来消滅のみを記録。全体N下限救済・再構築・報酬・後続イベント・P24以降は実装しない。",
  "excluded": ["通常山札からの到達と頻度", "敵の隠れ札確率と性格の推定", "未来札ごとに最適手を変える方策", "勝率・期待報酬・面白さの実証", "長期の防御反復や無傷滞在の最適性", "人による試遊と表示負担", "同時刻行動の衝突と汎用イベント全処理"],
}
target = ROOT / "input.json"
assert not target.exists(), "入力の既存固定版は上書きしない"
target.write_text(json.dumps(spec, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(hashlib.sha256(target.read_bytes()).hexdigest())
