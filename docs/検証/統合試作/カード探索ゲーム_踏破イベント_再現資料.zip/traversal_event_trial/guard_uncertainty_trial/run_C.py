"""Additional fixed H->E extension, kept separate from the frozen G trial."""
import copy
import hashlib
import json
from pathlib import Path
from run import Trial, canonical, sha, state_B, ending_summary

ROOT = Path(__file__).resolve().parent


def manual_expected(world, choice):
    """Scalar hand calculation, independent of the turn engine."""
    first, second = world["first_enemy"], world["next_enemy"]
    start_hp = world["P_HP"]
    hp_before = start_hp - (16 if first in ("C60","C100") else 0)
    cid, target = choice["card_id"], choice["target"]
    if cid == "Q" and target == "E":
        return hp_before, 0, True
    if first in ("C60","C20","C100"):
        if cid == "F" and world["draw_attribute"] == "C" and second != "A60" and not (second == "C20" and first != "C20"):
            return 0, 10, True
        return hp_before, 10, not (cid == "Q" and target == "L")
    assert first == "A60"
    if cid == "Q":
        assert target == "L"
        return max(0,start_hp-(16 if second == "C100" else 0)), 10, False
    if cid == "G":
        return start_hp-(0 if second == "C20" else 4), 10, True
    if world["draw_attribute"] == "C":
        return max(0,start_hp-(16 if second == "A60" else 0)), 10, True
    return max(0,start_hp-(0 if second == "C20" else 16)), 10, True


def main():
    path = ROOT / "input_C.json"
    input_hash = sha(path)
    spec = json.loads(path.read_text(encoding="utf-8"))
    base_path = ROOT / "input.json"
    base = json.loads(base_path.read_text(encoding="utf-8"))
    assert sha(base_path) == spec["base_input_sha256"]
    assert spec["worlds"] == base["trial_B"]["worlds"]
    b_result = json.loads((ROOT/"results.json").read_text(encoding="utf-8"))
    assert b_result["input_sha256"] == sha(base_path)
    A = {(c["id"],c["P_initial_HP"]):c for c in b_result["A_cases"]}
    condition_map = {"C60":"baseline","C20":"enemy_low_hit","A60":"deny_enemy_material","C100":"enemy_hits_without_light"}
    worlds, groups, early = [], {}, []
    for world in spec["worlds"]:
        trial = Trial(state_B(base,world))
        trial.play("P","H","E")
        trial.play("E","E_attack","P")
        # A has fewer total cards, but actors' endpoint HP/hit/crit and queue must agree.
        A_end = A[(condition_map[world["first_enemy"]],world["P_HP"])]["branches"][0]["end"]
        for who in ("P","E","L"):
            for key in ("hp","hit","crit","guard","active","next_at"):
                assert trial.s["actors"][who][key] == A_end["actors"][who][key]
        if trial.ended is not None:
            assert world["P_HP"] == 14 and world["first_enemy"] in ("C60","C100")
            out = trial.output("early")
            worlds.append({"setting":world,"reached_P12":False,"branches":[],"early_end":out})
            early.append(world["id"])
            continue
        trial.play("L","N",None)
        trial.refill("P")
        assert [trial.s["cards"][c]["remaining_life"] for c in ("Q","G","F")] == [1,1,2]
        public = trial.public_state()
        group_id = hashlib.sha256(canonical(public).encode()).hexdigest()[:16]
        group = groups.setdefault(group_id,{"public_state_id":group_id,"public_state":public,"worlds":[],"choices":{}})
        assert canonical(group["public_state"]) == canonical(public)
        group["worlds"].append(world["id"])
        branches = []
        for choice in trial.legal_P_choices():
            branch = copy.deepcopy(trial)
            branch.play("P",choice["card_id"],choice["target"])
            if branch.ended is None:
                assert branch.queue()[0] == {"actor":"E","time":16}
                branch.refill("E")
                branch.play("E","E_next","P")
            out = branch.output("after_E16_before_L18_and_P24")
            actual = (out["actors"]["P"]["hp"],out["actors"]["E"]["hp"],out["actors"]["L"]["active"])
            assert actual == manual_expected(world,choice),(world,choice,actual,manual_expected(world,choice))
            p12 = next(a for a in out["actions"] if a["actor"] == "P" and a["time"] == 12)
            assert p12["expired"] == [c for c in ("Q","G") if c != choice["card_id"]]
            if choice == {"card_id":"Q","target":"E"}:
                assert not out["actors"]["E"]["active"] and p12["damage"] == 24
                assert not any(a["time"] == 16 for a in out["actions"])
                assert "E_next" in out["destroyed"]
            branches.append({"P12_choice":choice,"end":out})
            key = canonical(choice)
            item = group["choices"].setdefault(key,{"P12_choice":choice,"outcomes_by_hidden_next_card":[]})
            item["outcomes_by_hidden_next_card"].append({"hidden_next_type_for_analysis_only":world["next_enemy"],**ending_summary(out)})
        worlds.append({"setting":world,"reached_P12":True,"public_state_id":group_id,"branches":branches})
    for group in groups.values():
        assert len(group["worlds"]) == 4
        for item in group["choices"].values():
            outs = item["outcomes_by_hidden_next_card"]
            assert [v["hidden_next_type_for_analysis_only"] for v in outs] == ["C60","C20","A60","C100"]
            item["outcome_set"] = {"P_HP_min":min(v["P_HP"] for v in outs),"P_HP_max":max(v["P_HP"] for v in outs),
                "P_survives_all_four_tested_cards":all(v["P_alive"] for v in outs),
                "P_alive_results":sorted({v["P_alive"] for v in outs}),
                "E_defeated_results":sorted({v["E_defeated"] for v in outs}),
                "L_present_results":sorted({v["L_present"] for v in outs})}
        group["choices"] = list(group["choices"].values())
    assert len(early) == 16 and len(groups) == 12
    # Initial H->E followed by Q->E is one fixed two-action plan. We do not
    # choose it separately for different hidden cards after seeing outcomes.
    fixed_plan = []
    for hp in (14,24):
        for draw in ("C","F"):
            selected = [w for w in worlds if w["setting"]["P_HP"] == hp and w["setting"]["draw_attribute"] == draw]
            outs = []
            for w in selected:
                out = w["early_end"] if not w["reached_P12"] else next(b["end"] for b in w["branches"] if b["P12_choice"] == {"card_id":"Q","target":"E"})
                outs.append({"first_enemy_for_analysis_only":w["setting"]["first_enemy"],"next_enemy_for_analysis_only":w["setting"]["next_enemy"],**ending_summary(out)})
            fixed_plan.append({"P_initial_HP":hp,"P_draw_attribute":draw,"fixed_choices":[{"time":0,"card_id":"H","target":"E"},{"time":12,"card_id":"Q","target":"E"}],
                "observed_outcomes":outs,"P_HP_range":[min(v["P_HP"] for v in outs),max(v["P_HP"] for v in outs)],
                "P_survives_all_tested_first_and_next_enemy_cards":all(v["P_alive"] for v in outs),
                "E_defeated_all_tested_first_and_next_enemy_cards":all(v["E_defeated"] for v in outs)})
    assert sha(path) == input_hash and sha(base_path) == spec["base_input_sha256"]
    result = {"status":spec["status"],"input_C_sha256":input_hash,"base_input_sha256":sha(base_path),"program_C_sha256":sha(Path(__file__)),"engine_sha256":sha(ROOT/"run.py"),
        "counts":{"C_worlds":64,"C_early_P_deaths":16,"C_worlds_reaching_P12":48,"C_public_states":12,"C_P12_branches":sum(len(w["branches"]) for w in worlds)},
        "checks":{"initial_H_matches_A_endpoints":True,"manual_C_endpoints":True,"Q_at_P12_deals_24_and_ends_before_E16":True,"Q_G_expiry":True,"four_hidden_next_cards_grouped":True},
        "C_public_groups":list(groups.values()),"C_worlds":worlds,"fixed_H_then_Q_plan":fixed_plan,
        "limits":[spec["horizon"],spec["limited_claim"],"確率・通常頻度・最適方策・長期防御反復・探索報酬は未検証。"]}
    (ROOT/"results_C.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({"counts":result["counts"],"checks":result["checks"],"fixed_H_then_Q_plan":[{k:v for k,v in row.items() if k != "observed_outcomes"} for row in fixed_plan]},ensure_ascii=False))


if __name__ == "__main__":
    main()
