"""A separately fixed follow-up: extend the initial H->E branch, no new worlds."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
base_path = ROOT / "input.json"
base = json.loads(base_path.read_text(encoding="utf-8"))
data = {
  "status": "B入力固定後の追加依頼を別試験Cとして固定。B入力と結果は変更しない。正式採用なし。",
  "scope": "同じ64世界でP0のみG防御からH→Eへ変更。初手で死亡したら終了、P12到達時はQ/G/F全合法手を列挙。Bとの比較で初回敵札や次回敵札を知って初手を変えない。",
  "base_input_sha256": hashlib.sha256(base_path.read_bytes()).hexdigest(),
  "worlds": base["trial_B"]["worlds"],
  "P0_choice": {"card_id":"H","target":"E"},
  "P12_refill": "山札Fを1枚補充して手札3。Q/G残期限1、F残期限2。属性C/FはBと同じ事前因子。",
  "field_effects": "H/Q/G/F/E_attack/E_next/Nおよび初期材料の場power/hit補正は全て0。主効果のpowerやhitを場補正へ流用しない。",
  "horizon": "P0→E4→L6→P12→E16。E撃破/P死亡はその記録まで。時刻24への延長はしない。",
  "fixed_before_C_run": "64世界と全合法手をC実行前に固定。敵未来札の検索・追加因子・確率なし。",
  "comparison": "HPに余裕があればP0 H→Eの後、P12に残るQ→Eで、独立な敵次札4種が使われる前にE撃破へ届くか。HP不足で初手死亡する世界も省略しない。B防御初手との比較は同じ世界で行うが、敵札ごとの事後的な初手選択を推奨方策にしない。",
  "limited_claim": "Qで確実に撃破できるのはここで仮定した全札・材料・光源継続・敵HP・行動列の範囲。通常頻度や探索全体の優位は未検証。",
}
dest = ROOT / "input_C.json"
assert not dest.exists(), "追加入力固定版を上書きしない"
dest.write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(hashlib.sha256(dest.read_bytes()).hexdigest())
