# 踏破イベントの再現資料

入力・コード・結果は試行仮設定。仕様案や数値の正式採用ではない。

- 追加A：大岩破壊／迂回の一手診断。3条件・12合法手。`traversal_event_trial/README.md` を参照。
- 追加B：岩の持続軽減と、岩から環境への回避支援。5条件・30合法手。`traversal_event_trial/presence_effect_trial/README.md` を参照。

追加Aは、このZIPと構築比較ZIP・判断表示と準備選択ZIPを同じ作業フォルダへ展開する。`traversal_event_trial` と `action_preview_trial` 等が兄弟になる。実行は `python3 traversal_event_trial/run.py`。

追加BはこのZIPだけで実行できる。展開した作業フォルダから `python3 traversal_event_trial/presence_effect_trial/run.py` を実行する。Python標準ライブラリのみ使用する。

両試験とも現在の一手のみ。試験用に設定した局面の到達手順、通常頻度、NPC介入、実退場・能力解除、札循環、報酬・保護、後続イベントは評価していない。

`manifest_traversal_event.json` に入力とコード、結果、追加Aの依存ZIPのSHA-256を記録する。
