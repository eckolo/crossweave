# 踏破イベントの再現資料

入力・コード・結果は試行仮設定。仕様案や数値の正式採用ではない。

- 追加A：大岩破壊／迂回の一手診断。3条件・12合法手。`traversal_event_trial/README.md` を参照。
- 追加B：岩の持続軽減と、岩から環境への回避支援。5条件・30合法手。`traversal_event_trial/presence_effect_trial/README.md` を参照。
- 追加C：光源を残す／除く一手と、次の生存敵の行動まで。5条件・20枝。`traversal_event_trial/light_source_trial/README.md` を参照。

追加Aは、このZIPと構築比較ZIP・判断表示と準備選択ZIPを同じ作業フォルダへ展開する。`traversal_event_trial` と `action_preview_trial` 等が兄弟になる。実行は `python3 traversal_event_trial/run.py`。

追加B・CはこのZIPだけで実行できる。展開した作業フォルダから次を実行する。Python標準ライブラリのみ使用する。

```bash
python3 traversal_event_trial/presence_effect_trial/run.py
python3 traversal_event_trial/light_source_trial/run.py
```

全試験とも手製の変更条件は初期状態からの到達未確認。A・Bは現在の一手のみ。Cは次の敵行動までと仮イベント結果の局所的な退場・源札残存を実装するが、光源自身の行動、全体循環、報酬・保護・後続イベントは扱わない。敵の非公開札だけが違う条件を、プレイヤーによる確定的な選び分けや等確率の試験へ読み替えない。

`manifest_traversal_event.json` に入力・コード・結果と、追加Aの依存ZIPのSHA-256を記録する。
