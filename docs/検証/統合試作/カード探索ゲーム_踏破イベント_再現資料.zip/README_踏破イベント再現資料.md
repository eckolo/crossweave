# 踏破イベントの再現資料

入力・コード・結果は試行仮設定。仕様案や数値の正式採用ではない。

- 追加A：大岩破壊／迂回の3条件12合法手。`traversal_event_trial/README.md`。
- 追加B：岩の持続軽減と環境への回避支援、5条件30合法手。`presence_effect_trial/README.md`。
- 追加C：光源を残す／除く一手と次の敵行動まで、5条件20枝。`light_source_trial/README.md`。
- 追加D：非公開札に備える防御・HP・補充と期限。初手50枝、防御継続64世界312枝、攻撃開始64世界（初手死亡16・継続200枝）。`guard_uncertainty_trial/README.md`。

各サブフォルダは `traversal_event_trial/` 内にある。追加D内部のA/B/C区分は、この一覧の追加A/B/Cとは別。

追加Aは、このZIPと構築比較ZIP・判断表示と準備選択ZIPを同じ作業フォルダへ展開する。`traversal_event_trial` と `action_preview_trial` 等が兄弟になる。実行は `python3 traversal_event_trial/run.py`。

追加B〜Dは、このZIPだけで再現できる。展開先から以下を実行する。Dの3本は記載順とし、最後の1本は既存結果の情報分類を再集約するだけである。

```bash
python3 traversal_event_trial/presence_effect_trial/run.py
python3 traversal_event_trial/light_source_trial/run.py
python3 traversal_event_trial/guard_uncertainty_trial/run.py
python3 traversal_event_trial/guard_uncertainty_trial/run_C.py
python3 traversal_event_trial/guard_uncertainty_trial/review_public_groups.py
```

全試験は手製の変更局面であり、初期構築からの通常到達は未確認。A/Bは一手、Cは次の敵行動まで。Dは防御・攻撃開始からPの次の手とE16までを扱い、必要な補充、余り札の期限切れ、光源の中立札設置を含む。全体の再構築・補填生成・報酬・回復・後続イベント、時刻24以降は実装しない。

敵の次札を見ず、同じ現在情報の同じ手に対する試験4型の結果集合を比較する。枝の比率を勝率にしない。全4型で生存する手があることと、未知の全札への安全保証や製品上の予告は別である。性格の予測精度、人間の試遊、探索全体の面白さは未評価。

`manifest_traversal_event.json` に各入力・コード・結果と、追加Aの依存ZIPのSHA-256を記録する。
