# 判断表示と準備選択の追補再現資料

記録日：2026-09-08（UTC）。資料区分：検証資料。基本設計0.30対応の試行条件・結果であり、新しい正式仕様ではない。

## 展開と依存

既存の「カード探索ゲーム_構築比較_再現資料.zip」を任意の作業フォルダへ展開し、同じフォルダへ本ZIPを展開する。既存のREADME.mdは上書きしない。本書はREADME_判断表示と準備選択.md。

action_preview_trial/、stay_choice_trial/ が、approved_input.json、integrated_trial/、neutral_target_trial/、cost_trial/、reuse_policy_trial/ と同じ階層に並ぶ。

下記コマンドはこの共通フォルダを作業ディレクトリにする。Python 3、Node.jsを使用。通常の再現は外部パッケージ不要。ブラウザ描画の追加検証に限りPlaywrightとブラウザ本体が必要。

## 表示を再生成する

```sh
python3 action_preview_trial/build_preview.py action-preview.html
node action_preview_trial/verify_dom.cjs action-preview.html
```

公開項目だけを含む同梱data_review.jsonで動き、非公開snapshotの再生成は不要。生成物は会話用HTMLフラグメント。単独文書のhead/body等は含めない。action_preview_trial/README.mdにはブラウザ検査のコマンドも記載した。

表示は6到達時点・25合法手の結果比較で、実際に札を実行して次の時点へ進むゲーム本体ではない。今回の一手の計算は照合済み。狭幅・明暗の描画、ネイティブキーボード操作、人間の読みやすさは未検証。クラウドブラウザのローカルHTMLアクセスがポリシーで拒否されたため、代替経路での描画検査も実施していない。

表示データの計算照合自体を再実行する場合のみ、既存のreuse_policy_trial/run.pyで元snapshotsを再生成してから次を実行する。

```sh
PYTHONDONTWRITEBYTECODE=1 python3 action_preview_trial/data_review.py
```

既存run.pyは全体の履歴を再生成するため、この手順は表示確認の必須作業ではない。

## 準備／進行の9経路を再実行する

```sh
PYTHONDONTWRITEBYTECODE=1 python3 stay_choice_trial/run.py
```

同梱した信頼済みの3個の小入力を使用し、追加の局面探索は行わない。結果ファイルは同じ名前で更新する。使用したpickleは当プロジェクトで生成・元状態と照合した入力だけに限定する。未知の外部pickleへ差し替えて実行しない。

実行前に固定した3局面×3方策、最大P4手と次P選択前までの条件付き比較。9経路27判断、公開攻撃予測53件を独立照合。今回のV一致攻撃は計3回で対象は全てPのみ、二択分岐0。詳細はstay_choice_trial/README.mdとreview.md/json。独立照合記録は成果物であり、run.pyの実行だけで第三者レビューが再発生する意味ではない。

## 結果の読み方

一手の表示計算が正しくても、準備と進行の選び分けが面白いことを証明しない。準備追加が有利になる対照は今回の3局面では確認できず、全方策が同じ札列になる例があった。勝率・通常頻度・長期最適性へ読み替えない。

行動予約・山札先頭の公開、同時刻V→P→E、コスト8/10/12等は試行前提。全主体の現在の次回行動順を常時公開する基本方針は、正式判断の候補として分けて記録した。未来のNPC行動内容を確定予告する採用ではない。

manifest_判断表示と準備選択.json に同梱ファイルと既存依存ZIPのSHA256を記録する。実行後は結果の再出力によりファイルハッシュが変わる場合がある。旧ZIPと旧エンジンは今回変更していない。
