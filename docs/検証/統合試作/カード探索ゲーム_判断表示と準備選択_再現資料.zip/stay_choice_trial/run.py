"""Three preselected reached states, three public policies, at most four P actions.

No engine/rule changes and no state search. Enumerates every eligible V attack
target through the existing branching scheduler. Other private state is fixed
to each reached source. Branch counts are not probabilities.
"""
from __future__ import annotations

import copy
import gzip
import hashlib
import json
import pickle
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT.parent))
from cost_trial.choice_analysis import advance_branches
from reuse_policy_trial.policy import predict_attack

CASES = [
    ("traversal_now", "P24_environment_first_seed17", 32),
    ("guarded_enemy_remaining", "P12_enemy_first_seed24", 18),
    ("first_turn_after_enemy", "P12_enemy_first_seed15", 24),
]
POLICIES = {"progress_now": 0, "prepare_two": 2, "prepare_one_then_progress": 1}


def save(name, obj):
    (ROOT / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def tie(card, hand):
    return card["remaining"], next(i for i, c in enumerate(hand) if c["id"] == card["id"])


def public_choices(state):
    choices = []
    for card in state["actors"]["P"]["hand"]:
        targets = [a for a in ("E", "V") if state["actors"][a]["active"]] if card["kind"] == "attack" and card["attr"] in state["field"] else [None]
        choices.extend({"card_id": card["id"], "target": target} for target in targets)
    return choices


def progress(state):
    """Finish V if possible, else finish E, else attack E (or surviving V).

    A per-action damage comparison is a greedy card-selection rule, not a
    combined utility value for rewards, HP, future states or whole branches.
    """
    hand, field, actors = state["actors"]["P"]["hand"], state["field"], state["actors"]
    attacks = []
    for c in hand:
        if c["kind"] == "attack" and c["attr"] in field:
            for target in ("V", "E"):
                if actors[target]["active"]:
                    prediction = predict_attack(state, c, field[c["attr"]], target)
                    attacks.append((c, target, prediction))
    for target in ("V", "E"):
        kills = [r for r in attacks if r[1] == target and r[2]["actual_hp_loss"] >= actors[target]["hp"]]
        if kills:
            card, target, prediction = min(kills, key=lambda r: tie(r[0], hand))
            return {"card_id": card["id"], "target": target}, "immediate_traversal" if target == "V" else "immediate_enemy_kill", prediction
    primary = "E" if actors["E"]["active"] else "V"
    rows = [r for r in attacks if r[1] == primary]
    if rows:
        card, target, prediction = min(rows, key=lambda r: (-r[2]["actual_hp_loss"], -r[2]["hit_gain"], *tie(r[0], hand)))
        return {"card_id": card["id"], "target": target}, "attack_primary_now", prediction
    guards = [c for c in hand if c["kind"] == "guard" and c["attr"] in field]
    if guards:
        card = min(guards, key=lambda c: tie(c, hand))
        return {"card_id": card["id"], "target": None}, "progress_fallback_matching_guard", None
    card = min(hand, key=lambda c: tie(c, hand))
    return {"card_id": card["id"], "target": None}, "progress_fallback_shortest_life", None


def preparation(state):
    """A fixed, deliberately simple preparation heuristic using public state.

    Preserve an existing guard with an unmatched card; otherwise start a
    matching guard. Prefer a lunge with a held, next-turn-live B attack among
    unmatched cards, else shortest remaining life. If neither is possible,
    renew a matching guard, else stop preparation. Never invent a pass.
    """
    actor, field = state["actors"]["P"], state["field"]
    hand = actor["hand"]
    unmatched = [c for c in hand if c["attr"] not in field]
    guards = [c for c in hand if c["kind"] == "guard" and c["attr"] in field]
    if not actor["guard"] and guards:
        c = min(guards, key=lambda c: tie(c, hand))
        return {"card_id": c["id"], "target": None}, "start_guard"
    if unmatched:
        leads = [c for c in unmatched if c["type"] == "l" and any(f["id"] != c["id"] and f["kind"] == "attack" and f["attr"] == c["attr"] and f["remaining"] >= 2 for f in hand)]
        c = min(leads or unmatched, key=lambda c: tie(c, hand))
        why = "place_lunge_with_held_followup" if leads else "place_shortest_life"
        return {"card_id": c["id"], "target": None}, why + ("_keep_guard" if actor["guard"] else "")
    if guards:
        c = min(guards, key=lambda c: tie(c, hand))
        return {"card_id": c["id"], "target": None}, "renew_guard"
    return None, "no_legal_defense_or_unmatched_placement"


def choose(state, remaining_preparations):
    if remaining_preparations > 0:
        choice, reason = preparation(state)
        if choice is not None:
            return choice, remaining_preparations - 1, {"mode": "preparation", "reason": reason}
    choice, reason, prediction = progress(state)
    return choice, 0, {"mode": "progress", "reason": reason, "prediction": prediction,
                       "preparation_unavailable": remaining_preparations > 0}


def card_info(t, cid):
    c = t.cards[cid]
    return {k: c[k] for k in ("id", "name", "type", "attr", "origin", "doomed", "destroyed", "remaining")}


def end_summary(t):
    return {"time": t.now, "outcome": t.outcome, "ready": t.ready,
            "actors": {a: {k: copy.deepcopy(v[k]) for k in ("hp", "active", "hit", "crit", "guard", "actions")} for a, v in t.actors.items()},
            "rewards": copy.deepcopy(t.rewards),
            "p_hand": [card_info(t, cid) for cid in t.actors["P"]["hand"]],
            "field": [card_info(t, cid) for cid in t.field.values()], "N": t.live_count()}


def compact_trace(t):
    rows = []
    for event in t.trace:
        kind = event["type"]
        if kind == "action":
            keep = ("type", "time", "actor", "card_id", "target", "matched_id", "mode", "damage", "actual_hp_loss", "hit_connected", "defense_applied", "expired")
            row = {k: copy.deepcopy(event.get(k)) for k in keep}
            row["card_name"] = t.cards[event["card_id"]]["name"]
            # Preserve expiry identity without presenting end-of-interval flags
            # or a re-drawn remaining lifetime as the value at expiry time.
            row["expired_cards"] = [{k: t.cards[cid][k] for k in ("id", "name", "type", "attr", "origin")} for cid in event["expired"]]
            rows.append(row)
        elif kind in ("event", "destroy", "retire", "reward_acquired", "rewards_protected", "current_exploration_rewards_lost", "target_choice", "observation_cutoff"):
            rows.append(copy.deepcopy(event))
    return rows


def walk(base, budget, history=(), elapsed_p=0):
    if base.outcome or elapsed_p >= 4:
        return [{"steps": list(history), "end": end_summary(base), "observation": "engine_terminal" if base.outcome else "four_P_actions_then_next_P_ready"}]
    state = base.public_state()
    choice, next_budget, explanation = choose(state, budget)
    assert choice in base.legal_choices() and choice in public_choices(state)
    t = base.clone()
    t.trace = []
    chosen_card = card_info(t, choice["card_id"])
    t.play_player(choice)
    leaves = []
    for after, targets in advance_branches(t):
        after.assert_invariants()
        assert after.outcome or after.ready
        assert after.force_v_target_once is None
        actions = [e for e in after.trace if e["type"] == "action"]
        assert sum(e["actor"] == "P" for e in actions) == 1
        step = {"p_step": elapsed_p + 1, "before_time": state["now"], "choice": choice,
                "card": chosen_card, "decision": explanation, "remaining_preparation_budget": next_budget,
                "v_targets": list(targets), "trace": compact_trace(after), "after": end_summary(after)}
        leaves.extend(walk(after, next_budget, history + (step,), elapsed_p + 1))
    return leaves


def main():
    spec = {"status": "試行仮設定。正式仕様・最適方策ではない", "cases": CASES, "policies": POLICIES,
            "horizon": "P最大4行動。その後次P補充済みまで。既存の死亡・踏破・P60手観測打切りで終了",
            "unchanged_rules": "neutral_target_trial / 統合検討26章。全コスト10、V攻撃対象P/E各50%の試験条件を維持",
            "source_selection": "既報26.4 CとB、および既報P12_enemy_first_seed15で敵退場後最初のP選択。結果による局面追加・差替えなし",
            "rng_contract": "新しいP方策は決定的でP選択乱数を使わない。元のP方策を1回空回しする再現ではない。NPC・配札・再構築・V対象の各保存乱数列は引継ぐ",
            "limits": "全V一致攻撃の合法対象を分岐。隠れNPC手札/判断・後続山札は保存状態条件付き。枝数は確率ではない。回復・増援・再出発・任意撤退・自己進行は追加しない"}
    save("input.json", spec)
    source_hashes = {}
    cases = []
    for case_id, label, index in CASES:
        packet_path = ROOT / (case_id + ".pkl.gz")
        if not packet_path.exists():
            source_path = ROOT.parent / "neutral_target_trial" / "snapshots" / (label + ".pkl.gz")
            source_bytes = source_path.read_bytes()
            source_hashes[label] = hashlib.sha256(source_bytes).hexdigest()
            states = pickle.loads(gzip.decompress(source_bytes))
            original = states[index]
            if case_id == "first_turn_after_enemy":
                assert index == next(i for i, state in enumerate(states) if not state.actors["E"]["active"])
            before = pickle.dumps(original)
            base = original.clone()
            base.trace = []  # Historical log omitted; physical state/RNG unchanged.
            assert base.state() == original.state()
            packet = {"source_label": label, "index": index, "source_file_sha256": source_hashes[label], "base": base}
            packet_path.write_bytes(gzip.compress(pickle.dumps(packet), mtime=0))
            assert before == pickle.dumps(original)
        packet_bytes = packet_path.read_bytes()
        packet = pickle.loads(gzip.decompress(packet_bytes))
        assert packet["source_label"] == label and packet["index"] == index
        base = packet["base"]
        before = pickle.dumps(base)
        result = {"id": case_id, "source_label": label, "source_P_index_zero_based": index,
                  "source_file_sha256": packet["source_file_sha256"],
                  "input_packet_sha256": hashlib.sha256(packet_bytes).hexdigest(),
                  "public_state": base.public_state(), "initial": end_summary(base), "policies": {}}
        for policy, budget in POLICIES.items():
            leaves = walk(base, budget)
            for number, leaf in enumerate(leaves):
                leaf["branch_id"] = f"{policy}_{number+1:02d}"
                leaf["P_actions"] = len(leaf["steps"])
                leaf["actual_preparation_actions"] = sum(step["decision"]["mode"] == "preparation" for step in leaf["steps"])
                leaf["P_hp_loss"] = base.actors["P"]["hp"] - leaf["end"]["actors"]["P"]["hp"]
                leaf["P_expired"] = [c for step in leaf["steps"] for e in step["trace"] if e["type"] == "action" and e["actor"] == "P" for c in e["expired_cards"]]
                leaf["destroyed_cards"] = [e for step in leaf["steps"] for e in step["trace"] if e["type"] == "destroy"]
            result["policies"][policy] = leaves
            assert pickle.dumps(base) == before, "source state mutated"
        save(case_id + ".json", result)
        cases.append({"id": case_id, "source": f"{label}_p{index+1:02d}", "initial": result["initial"],
                      "policies": {name: [{k: leaf[k] for k in ("branch_id", "P_actions", "actual_preparation_actions", "P_hp_loss", "observation", "end", "P_expired")} for leaf in rows] for name, rows in result["policies"].items()}})
    dependencies = ["approved_input.json", "integrated_trial/engine.py", "neutral_target_trial/engine.py", "cost_trial/engine.py", "cost_trial/choice_analysis.py", "reuse_policy_trial/policy.py"]
    hashes = {name: hashlib.sha256((ROOT.parent / name).read_bytes()).hexdigest() for name in dependencies}
    save("summary.json", {"cases": cases, "engine_dependencies_sha256": hashes, "probability_warning": "Conditional branches, never equal-weight probabilities or policy win rates"})
    print(json.dumps([{ "case": c["id"], "policy_branches": {n:len(r) for n,r in c["policies"].items()}} for c in cases]))


if __name__ == "__main__":
    main()
