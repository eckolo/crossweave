# 行動結果の事前表示：試作と再現資料

試行資料。6つの到達済み局面で、手札と持続ターゲットを切り替え、今回の行動結果を比較する。戦闘は進行しない。画面構成・数値・演算・予約情報の公開は、この試作をもって正式採用とはしない。

## 表示を生成・照合する

このディレクトリで実行する。Python 3とNode.jsを使用する。生成先・照合対象は任意のパスを指定でき、省略時は `/workspace/action-preview.html`。

```sh
python build_preview.py ./action-preview.html
node verify_dom.cjs ./action-preview.html
```

`preview.fragment.html` と `data_review.json` から表示を生成する。外部通信や敵の非公開手札を使用せず、表示側で戦闘を再計算しない。`verify_dom.cjs` は実際の表示スクリプトを簡易DOM上で実行し、全25合法手の命中・ダメージ・HP・防御終了・会心・失効札・コスト・次回予約順と、ターゲット保持・フォーカス復元の処理を照合する。結果は `dom_verification.json`。

## 実ブラウザで確認する

Playwrightと対応するChromiumを利用できる環境では、次を実行できる。

```sh
node verify_preview.cjs ./action-preview.html
```

Playwrightは、`CODEX_PRIMARY_RUNTIME_NODE_MODULES` が設定されていればその配下から、それ以外は通常の `require('playwright')` で読み込む。320・360・736pxの明暗両テーマで全25手、ネイティブ操作、フォーカス、表示の見切れを検査する。成功時に `ui_verification.json` と画面画像を生成する。

**今回、実ブラウザの描画検証は未実施。** ローカルにブラウザがなく取得はタイムアウトし、クラウドChromeのローカルファイル参照はセキュリティポリシーに拒否されたため停止した。簡易DOMでの25手合格を、見切れ・明暗の視認性・ネイティブ操作の確認として扱わない。人による読み取り時間・判断負担・面白さの検証も未実施。
