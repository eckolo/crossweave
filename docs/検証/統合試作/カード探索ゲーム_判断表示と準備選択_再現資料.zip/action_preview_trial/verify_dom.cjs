/* Browser-independent execution check. This does not validate browser layout or native input behavior. */
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const fragmentPath = process.argv[2] ?? '/workspace/action-preview.html';
const fragment = fs.readFileSync(fragmentPath, 'utf8');
const data = JSON.parse(fs.readFileSync(path.join(__dirname, 'data_review.json'), 'utf8'));
const document = {activeElement: null};

class Element {
  constructor(tag) {this.tagName = tag; this.children = []; this.attributes = {}; this.dataset = {}; this.listeners = {}; this.parent = null; this._text = ''; this.className = '';}
  append(child) {child.parent = this; this.children.push(child);}
  replaceChildren(...children) {this.children.forEach(child => {child.parent = null;}); this.children = []; this._text = ''; children.forEach(child => this.append(child));}
  set textContent(value) {this.replaceChildren(); this._text = String(value);}
  get textContent() {return this._text + this.children.map(child => child.textContent).join(' ');}
  setAttribute(name, value) {this.attributes[name] = String(value); if (name === 'class') this.className = value; if (name.startsWith('data-')) this.dataset[name.slice(5)] = String(value);}
  getAttribute(name) {return this.attributes[name] ?? null;}
  addEventListener(type, callback) {(this.listeners[type] ??= []).push(callback);}
  dispatch(type) {(this.listeners[type] ?? []).forEach(callback => callback());}
  focus() {document.activeElement = this;}
  contains(other) {return other === this || this.children.some(child => child.contains(other));}
  querySelectorAll(selector) {
    const matches = node => selector.startsWith('#') ? node.attributes.id === selector.slice(1)
      : selector.startsWith('.') ? node.className.split(' ').includes(selector.slice(1))
      : selector.startsWith('[data-') ? (() => {const match = selector.match(/^\[data-([^=]+)="([^"]+)"\]$/); return match && node.dataset[match[1]] === match[2];})()
      : node.tagName === selector;
    return this.children.flatMap(child => [...(matches(child) ? [child] : []), ...child.querySelectorAll(selector)]);
  }
  querySelector(selector) {return this.querySelectorAll(selector)[0] ?? null;}
}

const shell = new Element('document');
const stack = [shell];
const literal = fragment.split('<script type="application/json"')[0].replace(/<style>[\s\S]*?<\/style>/, '');
for (const token of literal.matchAll(/<\/?[a-z][^>]*>|[^<]+/gi)) {
  const value = token[0];
  if (value.startsWith('</')) {stack.pop(); continue;}
  if (value.startsWith('<')) {
    const tag = value.match(/^<([a-z]+)/i)[1];
    const node = new Element(tag);
    for (const attribute of value.matchAll(/([\w-]+)="([^"]*)"/g)) node.setAttribute(attribute[1], attribute[2]);
    stack.at(-1).append(node);
    if (!['input', 'br', 'hr', 'img', 'meta'].includes(tag)) stack.push(node);
  } else if (value.trim()) {
    const text = new Element('#text'); text._text = value.trim(); stack.at(-1).append(text);
  }
}
document.createElement = tag => new Element(tag);
document.getElementById = id => shell.querySelector('#' + id);
const root = document.getElementById('crossweave-action-preview');
const json = new Element('script');
json.setAttribute('id', 'cw-preview-data');
json.textContent = fragment.match(/<script type="application\/json" id="cw-preview-data">([\s\S]*?)<\/script>/)[1];
root.append(json);
const script = fragment.match(/<script>\s*([\s\S]*?)<\/script>/)[1];
vm.runInNewContext(script, {document, JSON, Boolean, Number, String, Object, Array}, {timeout: 5000});

const select = root.querySelector('#cw-scene');
assert.equal(select.value, 'A98');
const click = node => {assert(node); node.focus(); node.dispatch('click');};
const resultText = () => root.querySelector('.cw-result').textContent;
const lineValue = label => {
  const children = root.querySelector('#cw-result-lines').children;
  const index = children.findIndex(node => node.tagName === 'dt' && node.textContent === label);
  assert(index >= 0, label);
  return children[index + 1].textContent;
};
const names = {P: '自分', E: '敵', V: '環境'};
const records = [];
for (const scene of data.scenes) {
  select.value = scene.id; select.dispatch('change');
  for (const option of scene.options) {
    if (option.target) click(root.querySelector(`[data-target="${option.target}"]`));
    const oldTarget = root.querySelectorAll('.cw-actor').find(node => node.getAttribute('aria-pressed') === 'true').dataset.target;
    click(root.querySelector(`[data-card="${option.card_id}"]`));
    assert.equal(root.querySelector(`[data-card="${option.card_id}"]`).getAttribute('aria-pressed'), 'true');
    assert.equal(root.querySelector(`[data-target="${oldTarget}"]`).getAttribute('aria-pressed'), 'true');
    assert.equal(document.activeElement, root.querySelector(`[data-card="${option.card_id}"]`));
    const text = resultText();
    assert(lineValue('適用コスト').includes(`${option.mode === 'place' ? '設置' : '一致'} ${option.applied_cost}`));
    assert(lineValue('適用コスト').includes(`次予約 ${option.next_time}`));
    assert.equal(lineValue('次回予約順'), option.reservation_order.map(item => names[item.actor]).join(' → '));
    assert.equal(lineValue('自分の会心'), `${option.self_before.crit} → ${option.self_after.crit}`);
    const expired = option.expired_ids.map(id => scene.hand.find(card => card.id === id).name);
    assert.equal(lineValue('期限で失効'), expired.length ? expired.join('、') : 'なし');
    if (option.guard_ended) assert(lineValue('自分の防御').includes('→ 終了'));
    assert.equal(root.querySelectorAll('.cw-material').length, option.matched_id ? 1 : 0);
    if (option.target) {
      assert(text.includes(`${option.hit_connected ? '命中' : '未命中'} · ダメージ ${option.damage}`));
      assert(text.includes(`HP ${option.target_before.hp} → ${option.target_after.hp}`));
      assert(lineValue('対象の変化').includes(`命中度 ${option.target_before.hit} → ${option.target_after.hit}`));
    } else if (option.mode === 'place') {
      assert(text.includes('主効果は発動しない'));
    }
    assert.equal(text.includes('undefined'), false);
    assert.equal(text.includes('NaN'), false);
    records.push({scene: scene.id, card: option.card_id, target: option.target, damage: option.damage,
      defense_ended: option.guard_ended, expired_ids: option.expired_ids, cost: option.applied_cost,
      next_time: option.next_time, reservation_order: option.reservation_order,
      display_match: true, target_preserved: true, focus_restoration_logic: true});
  }
}
assert.equal(records.length, 25);
const result = {status: 'passed', method: 'Actual inline script execution in a minimal DOM harness; compared all 25 legal fixture options.',
  records, runtime_errors: [], browser_rendering: 'not_run',
  limitations: ['Browser rendering was not run: no local browser executable; local-file access by cloud Chrome was rejected by security policy.', 'DOM execution does not validate visual layout, theme contrast, native keyboard behavior or human usability.', 'verify_preview.cjs provides the pending real-browser checks for 320/360/736 px and both themes.']};
fs.writeFileSync(path.join(__dirname, 'dom_verification.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({status: result.status, legal_options_checked: records.length, browser_rendering: result.browser_rendering}, null, 2));
