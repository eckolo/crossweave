"""Extract public action-preview fixtures from three already reviewed states.

No product rule changes. Preview calculation accepts whitelisted public JSON
only; trusted local snapshots are used solely to reproduce and verify fixtures.
"""
from __future__ import annotations
import copy
import gzip
import hashlib
import json
import pickle
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PROBE = ROOT.parent
sys.path.insert(0, str(PROBE))
from cost_trial.engine import Trial
from cost_trial.choice_analysis import options

SOURCES = [
    ('A', 'l_place8_match12_other10_P12_enemy_first_reuse_public_seed15', 9),
    ('B', 'l_place8_match12_other10_P24_enemy_first_reuse_public_seed14', 42),
    ('C', 'all10_P12_enemy_first_reuse_public_seed14', 7),
]
CARD_KEYS = ('id', 'name', 'type', 'attr', 'kind', 'power', 'hit',
             'field_power', 'field_hit', 'life', 'remaining', 'origin',
             'doomed', 'place_cost', 'match_cost')
ACTOR_KEYS = ('active', 'hp', 'hit', 'crit', 'crit_gain', 'guard',
              'hand_count', 'deck_count')
TIE = {'V': 0, 'P': 1, 'E': 2}


def card_view(card):
    return {k: copy.deepcopy(card[k]) for k in CARD_KEYS} if card else None


def public_view(t):
    p = t.public_state()
    actors = {}
    for who, a in p['actors'].items():
        actors[who] = {k: copy.deepcopy(a[k]) for k in ACTOR_KEYS}
        actors[who]['next_time'] = a['next_at']
        actors[who]['deck_top'] = card_view(a['deck_top'])
    return {'time': p['now'], 'actors': actors,
            'field': {a: card_view(c) for a, c in p['field'].items()},
            'hand': [card_view(c) for c in p['actors']['P']['hand']]}


def legal_public(scene):
    result = []
    for c in scene['hand']:
        targets = ([who for who in ('E', 'V') if scene['actors'][who]['active']]
                   if c['kind'] == 'attack' and c['attr'] in scene['field'] else [None])
        result.extend({'card_id': c['id'], 'target': target} for target in targets)
    return result


def combat(a):
    return {k: copy.deepcopy(a[k]) for k in ('active', 'hp', 'hit', 'crit', 'guard')}


def predict(scene, choice):
    """Only the supplied current public state; no engine, private data or RNG."""
    c = next(c for c in scene['hand'] if c['id'] == choice['card_id'])
    m = scene['field'].get(c['attr'])
    actors = copy.deepcopy(scene['actors'])
    p = actors['P']
    target = choice['target']
    old_guard = copy.deepcopy(p['guard'])
    row = {**choice, 'mode': c['kind'] if m else 'place',
           'matched_id': m['id'] if m else None,
           'damage': 0, 'actual_hp_loss': 0, 'hit_connected': None,
           'hit_total': None, 'hit_gain': 0,
           'target_before': combat(actors[target]) if target else None,
           'self_before': combat(p), 'guard_ended': bool(m and old_guard),
           'defense_applied': False, 'attack_multiplier': None,
           'defense_multiplier': None, 'hit_multiplier': None,
           'critical_added': p['crit_gain'] if m else 0,
           'detail': []}
    if m:
        p['guard'] = None
        p['crit'] += p['crit_gain']
        row['detail'].append(f"一致で自分の会心度 +{p['crit_gain']}")
        if c['kind'] == 'guard':
            p['guard'] = {'value': c['power'], 'uses': 2}
            row['detail'].append(f"防御 {c['power']}・2回を設定（試験値）")
        elif c['kind'] == 'attack':
            d = actors[target]
            gain = c['hit'] + m['field_hit']
            total = d['hit'] + gain
            row.update(hit_total=total, hit_gain=gain, hit_connected=total >= 100)
            row['detail'].append(f"対象の命中度 {d['hit']} + 札 {c['hit']} + 場 {m['field_hit']} = {total}")
            d['hit'] = total
            if total >= 100:
                am = 1 + p['crit'] // 100
                hm = (100 + total) // 100
                dm = 1 + d['crit'] // 100 if d['guard'] else 0
                defense = d['guard']['value'] * dm if d['guard'] else 0
                damage = max(0, ((c['power'] + m['field_power']) * am - defense) * hm)
                row.update(damage=damage, actual_hp_loss=min(d['hp'], damage),
                           attack_multiplier=am, defense_multiplier=dm,
                           hit_multiplier=hm, defense_applied=d['guard'] is not None)
                row['detail'].append(f"試験のダメージ式：max(0, (({c['power']} + 場 {m['field_power']}) × 会心 {am} − 防御 {defense}) × 命中倍率 {hm}) = {damage}")
                d['hp'] = max(0, d['hp'] - damage)
                d['hit'] = 0
                if p['crit'] >= 100:
                    p['crit'] = 0
                if d['guard']:
                    d['guard']['uses'] -= 1
                    if d['crit'] >= 100:
                        d['crit'] = 0
                    if d['guard']['uses'] == 0:
                        d['guard'] = None
            else:
                row['detail'].append('100未満のため未命中・ダメージ0。加算後の会心度は保持')
    else:
        row['detail'].append('同属性の場札がないため設置。主効果・会心加算は発動しない')
    expired = []
    remaining = []
    for held in scene['hand']:
        if held['id'] == c['id']:
            continue
        life = held['remaining'] - 1
        remaining.append({'card_id': held['id'], 'remaining_before': held['remaining'],
                          'remaining_after': life, 'expires': life <= 0})
        if life <= 0:
            expired.append(held['id'])
    cost = c['match_cost'] if m else c['place_cost']
    p['next_time'] = scene['time'] + cost
    row.update(target_after=combat(actors[target]) if target else None,
               self_after=combat(p), expired_ids=expired, hand_remaining_after=remaining,
               applied_cost=cost, next_time=p['next_time'],
               reservation_order=[{'actor': who, 'time': a['next_time']}
                   for who, a in sorted(actors.items(), key=lambda kv: (kv[1]['next_time'] if kv[1]['next_time'] is not None else float('inf'), TIE[kv[0]]))
                   if a['active']])
    row['reservation_note'] = '現在の予約を並べたもの。途中の行動・退場・効果による更新を予告しない'
    row['scope'] = '自分の今回の行動直後まで。次回補充や他主体の行動結果は含めない'
    return row


def verify_and_scene(t, sid, label, case_id, context, future_notes):
    before = pickle.dumps(t)
    scene = {'id': sid, 'label': label, 'case_id': case_id,
             'brief_context': context, **public_view(t),
             'may_change_before_next_action': future_notes}
    choices = legal_public(scene)
    assert choices == t.legal_choices(), (sid, 'legal choices')
    previews = []
    for choice in choices:
        row = predict(scene, choice)
        child = t.clone()
        child.trace = []
        child.play_player(choice)
        assert child.outcome is None, 'Event-ending preview is outside these six fixtures'
        assert all(not a['active'] or a['hp'] > 0 for a in child.actors.values())
        assert all(child.actors[who]['active'] == a['active'] for who, a in t.actors.items()), 'Actor-retirement preview is outside these fixtures'
        actions = [e for e in child.trace if e['type'] == 'action']
        assert len(actions) == 1 and actions[0]['actor'] == 'P'
        e = actions[0]
        for k in ('mode', 'matched_id', 'damage', 'actual_hp_loss', 'hit_gain',
                  'defense_applied', 'applied_cost', 'attack_multiplier',
                  'defense_multiplier', 'hit_multiplier'):
            assert row[k] == e[k], (sid, choice, k, row[k], e[k])
        assert row['hit_connected'] == (e['hit_connected'] if e['mode'] == 'attack' else None)
        assert row['self_after'] == combat(child.actors['P'])
        if choice['target']:
            assert row['target_after'] == combat(child.actors[choice['target']])
        assert row['expired_ids'] == e['expired']
        assert row['next_time'] == child.actors['P']['next_at']
        assert row['guard_ended'] == bool(e['old_guard_ended'])
        for remaining in row['hand_remaining_after']:
            actual_remaining = child.cards[remaining['card_id']]['remaining']
            assert (actual_remaining is None if remaining['expires']
                    else remaining['remaining_after'] == actual_remaining)
        previews.append(row)
    assert pickle.dumps(t) == before
    scene['options'] = previews
    return scene


def main():
    bases, sources = {}, []
    for key, label, index in SOURCES:
        path = PROBE / 'reuse_policy_trial' / 'snapshots' / (label + '.pkl.gz')
        raw = path.read_bytes()
        bases[key] = pickle.loads(gzip.decompress(raw))[index]
        sources.append({'case_id': key, 'source_rollout': label, 'P_choice_index': index,
                        'snapshot_file_sha256': hashlib.sha256(raw).hexdigest()})
    a, b, c = (bases[x] for x in 'ABC')
    aw = a.clone()
    aw.select_rollout_choice()  # Preserve existing comparison's NPC/RNG condition.
    lead_a = next(x for x in aw.legal_choices() if aw.cards[x['card_id']]['type'] == 'l')
    af = options(aw, lead_a, aw.cost_condition)
    assert len(af) == 1
    after_a = af[0][1]
    assert after_a.now == 98 and not af[0][0]['intervening_actions']
    cw = c.clone()
    cw.select_rollout_choice()
    lead_c = next(x for x in cw.legal_choices() if cw.cards[x['card_id']]['type'] == 'l')
    cf = options(cw, lead_c, cw.cost_condition)
    by_target = {tuple(row['v_targets']): after for row, after in cf}
    assert set(by_target) == {('P',), ('E',)}
    scenes = [
        verify_and_scene(a, 'A90', '局面 A・時刻90', 'A',
            '今はB属性の場札がなく、手札に踏み込みが2枚ある。',
            ['選ぶ札で自分の次の予約時刻が変わる。現在の予約と同時刻の順序を確認できる。',
             '設置札は以後に一致材料として使えるが、追撃後の安全や未来のNPCの選択は未確定。']),
        verify_and_scene(after_a, 'A98', '局面 A・時刻98', 'A',
            '踏み込みを置いた後、自分に行動が戻った時点。同時刻の敵はまだ行動していない。',
            ['今回の攻撃結果は現在値から確定する。攻撃後に敵・環境がどの札や対象を選ぶかは確定表示しない。']),
        verify_and_scene(b, 'B426', '局面 B・時刻426', 'B',
            '敵は退場済み。環境は手札上限1枚で、現在の手札は0枚。山札先頭は重撃。',
            ['どの札を設置しても、現在の予約では環境が自分の次回より先。渡す場効果を比べられる。',
             '表示する自分の今回の結果に、環境の次の攻撃ダメージは合算しない。']),
        verify_and_scene(c, 'C70', '局面 C・時刻70', 'C',
            '防御が残り、会心度は200。B属性の場札はまだない。',
            ['現在の予約では、次の自分までに敵・環境が介在する。場札だけでなく命中度・会心度・防御も変わり得る。',
             '次の重撃が今の計算通りになるとは限らない。']),
        verify_and_scene(by_target[('P',)], 'C80P', '局面 C・時刻80（状態1）', 'C',
            '踏み込み設置後の比較状態。環境の攻撃を自分が防ぎ、現在は会心度0・防御残1回。',
            ['今ある材料と現在の会心度・命中度で今回の札を選び直せる。',
             'この状態は先行する敵の実行動を固定した比較例であり、時刻70から保証された未来ではない。']),
        verify_and_scene(by_target[('E',)], 'C80E', '局面 C・時刻80（状態2）', 'C',
            '踏み込み設置後の比較状態。環境の攻撃は敵に命中し、現在の敵命中度は0。',
            ['材料が残っていても、今回の重撃の命中は現在の対象命中度から再計算する。',
             'この状態は先行する敵の実行動を固定した比較例であり、時刻70から保証された未来ではない。']),
    ]
    result = {
        'title': '今回の一手の結果表示：既存3局面・6時点',
        'status': '試行資料。表示の基本方針以外の画面・数値・演算・先頭札公開範囲は正式採用ではない。',
        'visibility_assumptions': [
            '既存局所試験の前提として、現在のHP・命中度・会心度・防御・行動予約・山札先頭1枚を公開。',
            '自分の手札と場札は公開。敵・環境の手札の内容、先頭より先の山札順、選択乱数は非公開。',
            '同時刻の順序は、この試験では環境→自分→敵。主体の次予約は確定した未来の実行順とは異なる。',
            '命中度は攻撃対象側で蓄積する試験演算。会心度は各主体が攻撃と防御で共用する。',
            '対象を切り替えても設置・防御札の結果は変わらず、追加の対象選択を要求しない。',
        ],
        'cases': [
            {'id': 'A', 'scene_ids': ['A90', 'A98'], 'review_focus': '設置と一致でコストが異なるとき、現在の結果と次予約を区別して読めるか。'},
            {'id': 'B', 'scene_ids': ['B426'], 'review_focus': '今回のダメージが全て0でも、場に渡す補正と期限から選び分けを考えられるか。'},
            {'id': 'C', 'scene_ids': ['C70', 'C80P', 'C80E'], 'review_focus': '材料が残っていても現在値を読み直し、防御終了・会心の保持/消費を判別できるか。'},
        ],
        'scenes': scenes,
        'verification': {
            'scene_count': len(scenes), 'legal_option_count': sum(len(s['options']) for s in scenes),
            'public_projection': 'Actor/card key allowlists. No full state, NPC hand, future deck sequence, RNG, choice recommendations or future action trace exported.',
            'method': 'Independent prediction from whitelisted current public JSON, checked against exactly one play_player call for every legal option. No NPC action executed by previews.',
            'source_mutation': False, 'all_checks_passed': True,
            'human_playtest': '未実施。読み取り時間・選択傾向・面白さの実証ではない。',
            'event_boundary_scope': '今回の25合法手にHP0・主体退場・イベント終了はないことを実処理で確認。これらを伴う予約の失効表示は未検証であり、汎用プレビューとしての対応を主張しない。',
            'source_identity': sources,
        },
    }
    text = json.dumps(result, ensure_ascii=False, indent=2) + '\n'
    forbidden = ('target_rng_state', 'before_actors', 'public_policy_memory', 'fallback_choice', 'natural_target', 'target_draws')
    assert not any('"' + k + '"' in text for k in forbidden)
    (ROOT / 'data_review.json').write_text(text, encoding='utf-8')
    lines = ['# 行動結果事前表示用データの確認', '',
             '既存の3局面から6時点を切り出した試行用データ。基本設計0.30の採用範囲は「今回の公開情報から確定する結果を表示する基本方針」であり、以下の仮値・配置・先頭札公開は正式仕様ではない。', '',
             '| 時点 | 現在時刻 | 合法な札・対象の組数 |', '| --- | ---: | ---: |']
    for s in scenes:
        lines.append(f"| {s['label']} | {s['time']} | {len(s['options'])} |")
    lines += ['', f"全{result['verification']['legal_option_count']}選択について、公開情報だけの別計算と既存エンジンの今回の行動直後が一致した。プレビュー検証中はNPCを進めていない。元スナップショットは不変。", '',
              'JSONの`scenes`だけが画面用。各時点の`options`には全合法な札・対象の組と、その一手による命中・HP・会心・防御・期限・次予約を含む。敵手札、先頭より先の山札順、乱数、AIの推奨、未来の行動履歴は出力しない。', '',
              'A98はA90で最初の踏み込みを置いた後、無介在で到達する時点。C80の2状態は、既存比較と同じ先行敵行動に条件付け、環境の対象を分けた到達状態。時刻70からの全未来でも、等確率の二択でもない。UIのシーン切替は状態比較であり、プレイヤーの実行結果を保証する機能ではない。', '',
              '現在の予約は札による次回コストを反映した1件ずつの予約であり、介在主体の連続行動や途中の更新を展開した未来タイムラインではない。今回の確定ダメージに未来のNPCダメージを混ぜない。', '',
              '評価上、B426とC70は全合法手が設置であり今回ダメージが全て0。結果数字だけを強調すると、場効果や温存を考える材料が埋もれる。A98とC80は、同じ場材料でも対象の命中度・自分の会心が違う場合の読み替え確認に使える。これは画面設計の仮説であり、人間の試遊結果ではない。', '',
              '## 予約情報で読み取れる差', '',
              '- A90：踏み込み設置なら次の自分98は敵98より同時刻優先で、環境100より早い。受け流し設置なら次の自分100までに敵98と環境100が介在する。単なる「8対10」というコスト差を、材料に触れられるかという具体的な差へ読み替えられる。',
              '- B426：踏み込み設置の次434も、他の札の次436も、環境430の後になる。短い設置コストでも次の環境行動を追い越せず、渡す場補正の評価が残る。',
              '- C70：次の自分80までに敵70・環境80が介在することは予約から読めるが、敵の札選択や環境の対象は予約だけでは決まらない。予約公開を確定した追撃ダメージの公開へ拡張しない。', '',
              '以上は、既存局面に選択上の意味を持つ予約情報があるという根拠。予約を見せる／隠す比較で人間の選択・判断時間がどう変化したかは未検証であり、表示の面白さの実証ではない。先頭札の公開も現行試行前提で、予約公開とセットで正式採用した扱いにしない。', '',
              '今回の25合法手では、処理直後のHP0・主体退場・イベント終了は発生しない。既存エンジンで確認し、再生成時にも範囲外なら停止する検査を設けた。これらに伴う次回予約の失効は汎用実装へ接続する際の残検証であり、本データで確認済みとは扱わない。', '',
              '再生成：`python integration_probe/action_preview_trial/data_review.py`。既存の`reuse_policy_trial/snapshots/`が必要（元のrun.pyで再生成可能）。', '',
              '## 各選択の現在結果', '']
    names = {'P':'自分','E':'敵','V':'環境',None:'—'}
    for s in scenes:
        lines += [f"### {s['label']}", '', s['brief_context'], '', '| 札・対象 | 今回 | HP減少 | 自分の会心 | 防御 | 期限切れ | 次予約 |', '| --- | --- | ---: | --- | --- | --- | ---: |']
        cards = {x['id']:x for x in s['hand']}
        for r in s['options']:
            name = cards[r['card_id']]['name'] + '（' + r['card_id'] + '）'
            mode = '設置' if r['mode']=='place' else ('防御一致' if r['mode']=='guard' else ('一致・命中' if r['hit_connected'] else '一致・未命中'))
            guard = '終了' if r['guard_ended'] else ('維持' if r['self_after']['guard'] else 'なし')
            if r['mode']=='guard': guard += '→新防御'
            expired = '、'.join(cards[x]['name'] for x in r['expired_ids']) or 'なし'
            lines.append(f"| {name} → {names[r['target']]} | {mode} | {r['actual_hp_loss']} | {r['self_before']['crit']}→{r['self_after']['crit']} | {guard} | {expired} | {r['next_time']} |")
        lines += [''] + [f'- {x}' for x in s['may_change_before_next_action']] + ['']
    (ROOT / 'data_review.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(json.dumps({'scenes': len(scenes), 'legal_options': result['verification']['legal_option_count'], 'passed': True}, ensure_ascii=False))


if __name__ == '__main__':
    main()
