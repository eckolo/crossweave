/* Validate presentation against the public calculated fixture; no combat forecast is recomputed here. */
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const { chromium } = process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES
  ? require(path.join(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES, 'playwright'))
  : require('playwright');

(async () => {
  const here = __dirname;
  const data = JSON.parse(fs.readFileSync(path.join(here, 'data_review.json'), 'utf8'));
  const fragmentPath = process.argv[2] ?? '/workspace/action-preview.html';
  const fragment = fs.readFileSync(fragmentPath, 'utf8');
  const browser = await chromium.launch({headless: true});
  const records = [];
  const runtimeErrors = [];
  const unexpectedRequests = [];
  for (const color of ['light', 'dark']) {
    for (const width of [320, 360, 736]) {
      const page = await browser.newPage({viewport: {width, height: 1200}, colorScheme: color});
      page.on('pageerror', error => runtimeErrors.push(error.message));
      page.on('request', request => unexpectedRequests.push(request.url()));
      await page.setContent(`<html style="color-scheme:${color}"><head><meta charset="utf-8"><style>body{margin:0;font-family:system-ui;font-size:14px}strong{font-weight:500}</style></head><body>${fragment}</body></html>`);
      assert.equal(await page.locator('#cw-scene').inputValue(), 'A98');
      let checked = 0;
      for (const scene of data.scenes) {
        await page.selectOption('#cw-scene', scene.id);
        for (const option of scene.options) {
          if (option.target) await page.locator(`[data-target="${option.target}"]`).click();
          await page.locator(`[data-card="${option.card_id}"]`).click();
          assert.equal(await page.locator(`[data-card="${option.card_id}"]`).getAttribute('aria-pressed'), 'true');
          const result = await page.locator('.cw-result').innerText();
          assert(result.includes(`次予約 ${option.next_time}`), `reservation ${scene.id}`);
          assert(result.includes(`${option.mode === 'place' ? '設置' : '一致'} ${option.applied_cost}`), `cost ${scene.id}`);
          if (option.target) {
            assert(result.includes(`${option.hit_connected ? '命中' : '未命中'} · ダメージ ${option.damage}`), `damage ${scene.id}`);
            assert(result.includes(`HP ${option.target_before.hp} → ${option.target_after.hp}`), `target hp ${scene.id}`);
          } else if (option.mode === 'place') {
            assert(result.includes('主効果は発動しない'));
          }
          assert(result.includes(`${option.self_before.crit} → ${option.self_after.crit}`), `crit ${scene.id}`);
          if (option.guard_ended) assert(result.includes('→ 終了'), `guard ending ${scene.id}`);
          const expectedMaterials = option.matched_id ? 1 : 0;
          assert.equal(await page.locator('.cw-material').count(), expectedMaterials);
          for (const id of option.expired_ids) {
            assert(result.includes(scene.hand.find(card => card.id === id).name), `expiry ${scene.id}`);
          }
          const overflow = await page.evaluate(() => {
            const root = document.getElementById('crossweave-action-preview');
            const outer = root.getBoundingClientRect();
            const elements = [...root.querySelectorAll('*')].filter(node => node.checkVisibility() && node.getBoundingClientRect().width > 0);
            return {page: document.documentElement.scrollWidth > window.innerWidth, elements: elements.filter(node => {
              const box = node.getBoundingClientRect();
              return box.left < outer.left - 1 || box.right > outer.right + 1;
            }).map(node => node.tagName + '.' + node.className)};
          });
          assert.equal(overflow.page, false, `page overflow ${color} ${width} ${scene.id}`);
          assert.deepEqual(overflow.elements, [], `element overflow ${color} ${width} ${scene.id}`);
          checked++;
        }
      }
      await page.selectOption('#cw-scene', 'A98');
      const scene = data.scenes.find(item => item.id === 'A98');
      const second = scene.hand[1].id;
      await page.locator('[data-target="V"]').focus();
      await page.keyboard.press('Enter');
      assert.equal(await page.locator('[data-target="V"]').getAttribute('aria-pressed'), 'true');
      assert.equal(await page.locator('[data-target="V"]').evaluate(node => node === document.activeElement), true);
      await page.locator(`[data-card="${second}"]`).focus();
      await page.keyboard.press('Space');
      assert.equal(await page.locator(`[data-card="${second}"]`).getAttribute('aria-pressed'), 'true');
      assert.equal(await page.locator('[data-target="V"]').getAttribute('aria-pressed'), 'true', 'persistent target');
      assert.equal(await page.locator(`[data-card="${second}"]`).evaluate(node => node === document.activeElement), true);
      await page.locator('summary').click();
      assert.equal(await page.locator('#cw-detail').getAttribute('open'), '');
      assert((await page.locator('#cw-calculation').innerText()).includes('現在の予約'));
      await page.locator('summary').click();
      await page.locator('[data-target="E"]').click();
      await page.locator(`[data-card="${scene.hand[0].id}"]`).click();
      if (width !== 320) await page.screenshot({path: path.join(here, `preview_${color}_${width}.png`), fullPage: true});
      records.push({color, width, legal_options_checked: checked, keyboard: true, target_persistence: true, details_toggle: true, overflow: false});
      await page.close();
    }
  }
  await browser.close();
  assert.deepEqual(runtimeErrors, []);
  assert.deepEqual(unexpectedRequests, []);
  const result = {status: 'passed', records, runtime_errors: runtimeErrors, network_requests: unexpectedRequests,
    limitations: ['Visible result/interaction/layout checks only; not a human usability or fun evaluation.', 'Only the six fixed reachable checkpoints and 25 legal options are covered.']};
  fs.writeFileSync(path.join(here, 'ui_verification.json'), JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify(result, null, 2));
})().catch(error => {console.error(error); process.exitCode = 1;});
