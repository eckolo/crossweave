"""Build the inline Q04 comparison surface from independently calculated public data."""
from pathlib import Path
import argparse
import json

HERE = Path(__file__).resolve().parent


def build(destination: Path = Path('/workspace/action-preview.html')) -> dict:
    source = HERE / 'preview.fragment.html'
    dataset = json.loads((HERE / 'data_review.json').read_text(encoding='utf-8'))
    template = source.read_text(encoding='utf-8')
    marker = '__CROSSWEAVE_PREVIEW_DATA__'
    assert template.count(marker) == 1
    public_payload = {'scenes': dataset['scenes']}
    encoded = json.dumps(public_payload, ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/')
    output = template.replace(marker, encoded)
    assert len(output.encode('utf-8')) < 1_000_000
    assert '<!doctype' not in output.lower()
    assert not any(word in output for word in ('fetch(', 'XMLHttpRequest', 'WebSocket'))
    destination.write_text(output, encoding='utf-8')
    return {'path': str(destination), 'bytes': destination.stat().st_size, 'scenes': len(dataset['scenes'])}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('destination', nargs='?', type=Path, default=Path('/workspace/action-preview.html'),
                        help='Output fragment path; defaults to /workspace/action-preview.html')
    print(json.dumps(build(parser.parse_args().destination), ensure_ascii=False))
